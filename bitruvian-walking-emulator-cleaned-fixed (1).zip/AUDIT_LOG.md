# Bitruvius Design Audit Log

## [v1.0] - Lockdown Milestone
- **Head**: Implemented "Flattened Head" design. Inverted wedge shape with base width (neck) at 25% of unit and top width (skull) at 55%.
- **Shoulders**: Adjusted RIGGING to lower shoulder anchors by one `ANATOMY.COLLAR` length.
- **Hands/Feet**: Redesigned `hand-foot-arrowhead-shape` with a ultra-thin base (30% width).
- **Parenting**: Confirmed Olive Collar is the parent for Head, RShoulder, and LShoulder.

## [v1.5] - Dynamic Joint Constraints
- **Joint Modes**: Added 5 behavioral modes for joints, cycled via Double-Click:
    - **Locked (Default)**: Standard FK.
    - **Stretch**: Child counter-rotates (-1:1).
    - **Curl**: Child rotates with parent (+1:1).
    - **Tense**: Slight resistance (-0.5:1).
    - **Loose**: Lazy follow (+0.5:1).

## [v1.6] - Chain Selection
- **Triple-Click Interaction**: Detects triple-clicking segments to select logical groups (Arms, Legs, Core).

## [v1.7] - Unified Command HUD
- **Command HUD**: Implemented persistent legend and status monitor.

## [v1.8] - Simplified Interaction Model
- **Lock Removal**: Completely removed the "Freeze/Lock Joint" feature and UI icon to reduce cognitive load and streamline posing.
- **Interaction Hierarchy**:
    - **Single-Click**: Select part for individual adjustment.
    - **Double-Click**: Cycle constraint behavior (HUD updates to show mode).
    - **Triple-Click**: Select entire logical chain (e.g., full arm).
- **HUD Update**: Updated legend to reflect the removal of locking and the focus on kinetic behaviors.

## [v1.9] - Friction Pass (A -> B continuity)
Measured with `npm run probe` (3,672 headless A->B transitions through solver -> pose-follow -> stabilizer; plus a real-rig body-turn probe).
- **Solver endpoints**: lead/lag stagger used `clamp(t + offset)`, so lagging joints never reached B (up to 7 deg short, then popped on handoff) and leading joints started moving at t=0 (up to 19 deg off A). Replaced with an endpoint-exact time remap. `solve(A,B,0)==A`, `solve(A,B,1)==B`.
- **easePowerRise mid-curve jump**: ease-in half (`2.4*t^3`) did not meet the ease-out half at t=0.5, a 20%-of-delta one-frame pop on every rising/exploding move (~60 deg shoulder jump). Now a true symmetric power ease.
- **Compensation arcs** (CoM pitch, windup dip, swing-foot clearance, drag): now sin^2 bells, zero value AND zero slope at both ends; foot-clearance / weight-shift gates are continuous ramps instead of hard thresholds; elbow/hand drag is tanh-capped (was up to ~30 deg past target on 220 deg arm swings).
- **Out-of-range targets**: mood x intensity scaling pushed 1,319 joint targets past +-180 deg, which the rig wraps onto the opposite side of the body, and the stabilizer then re-squashed them and read the squash as tension (firing unspool/stumble on ~1/3 of transitions). The generator now soft-saturates every joint to 84% of its friction limit; the stabilizer ceiling is identity inside its envelope and only counts tension above 90%.
- **Limits**: hands raised 88 -> 160 deg (Promethean wing-hands reach ~150); root step caps 12/16 -> 20/24 px/frame (a sit->leap peaks ~17).
- **Body turns**: view changes teleported arm/leg/rib pivots up to ~437 stage units in one frame. Applied shifts now follow a critically damped spring (zero start velocity, retarget-safe); mirror flags swap at the turn midpoint.
- **Intent lead**: in Screensaver holds, the last ~0.9 s leans <=7.5% (angles only, root planted) toward the already-chosen Point B.
- **Build breakers**: `PUPPYT_DEG` was undefined in `piggy-foot.ts` (ReferenceError in the foot FK path); `MoodWheel` lacked the `ClickWheelMenuItem` type and the `menuTree`/`statusHeadline` props `App.tsx` passes (iPod menu now renders).
