// Verifies body-view turns glide on the REAL rig: max per-frame lateral jump of any node pivot when the view changes.
import fs from 'node:fs';
import { buildPuppytRigGraph, applyPoseToPuppytRig } from '../utils/puppyt-rig';
import { buildProcessEndpoint, getBodyViewPoseOffsets, createBodyViewShiftState } from '../utils/process-engine';
import { CORE_DEFAULT_PIVOT_OFFSETS } from '../constants';
const DEFAULT_PROPORTIONS = Object.fromEntries(['head','collar','torso','waist','l_upper_arm','l_lower_arm','l_hand','r_upper_arm','r_lower_arm','r_hand','l_upper_leg','l_lower_leg','l_foot','r_upper_leg','r_lower_leg','r_foot','l_toe','r_toe'].map(k => [k, { w: 1, h: 1 }]));
const data = JSON.parse(fs.readFileSync(new URL('../public/rig-data.json', import.meta.url), 'utf8'));
const graph: any = buildPuppytRigGraph(data.rig, data.parts);
const smooth = process.argv[2] !== 'instant';
const state = createBodyViewShiftState();
const views = ['front','sideR','threeQuarterL','back','front'] as const;
let worst = 0, worstId = '', prev: Record<string,[number,number]> | null = null, frames = 0;
let viewIdx = 0;
for (let f = 0; f < 60 * 6; f++) {
  if (f > 0 && f % 72 === 0) viewIdx++;
  const view = views[Math.min(viewIdx, views.length - 1)];
  const pose = buildProcessEndpoint('contrapposto','composed','standard',view,false,f/60*2).pose;
  applyPoseToPuppytRig(graph, pose, CORE_DEFAULT_PIVOT_OFFSETS, DEFAULT_PROPORTIONS as any, true, {
    bodyView: view, nodeFlipX: getBodyViewPoseOffsets(view,false).flipX,
    ...(smooth ? { viewShiftState: state, dt: 1/60 } : {}),
  });
  const cur: Record<string,[number,number]> = {};
  for (const n of graph.nodes) cur[n.id] = [n.piv[0], n.piv[1]];
  if (prev && f % 72 > 1) { for (const id in cur) { const d = Math.abs(cur[id][0]-prev[id][0]); if (d>worst){worst=d;worstId=id;} } }
  // turn frames only (first 20 frames after each switch)
  if (prev && f % 72 <= 1 && f>0) { let w=0,wid=''; for (const id in cur){const d=Math.abs(cur[id][0]-prev[id][0]); if(d>w){w=d;wid=id;}} (globalThis as any).__turn=Math.max((globalThis as any).__turn||0,w); (globalThis as any).__turnId = w>=((globalThis as any).__turn||0)?wid:(globalThis as any).__turnId; }
  prev = cur; frames++;
}
console.log(smooth ? 'SMOOTHED' : 'INSTANT', JSON.stringify({ worstSteadyStepPx: +worst.toFixed(2), worstFrameOfTurnJumpPx: +(((globalThis as any).__turn)||0).toFixed(1), at: (globalThis as any).__turnId }));
