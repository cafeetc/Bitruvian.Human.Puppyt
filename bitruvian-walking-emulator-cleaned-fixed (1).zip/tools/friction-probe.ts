// Friction probe: runs the real A->B solver + pose-follow + stabilizer chain headlessly
// and reports endpoint pops, velocity/accel spikes, overshoot, and unwanted fall/unspool triggers.
import {
  STARTER_STANCE_CATALOG, buildProcessEndpoint, solveKinematicInBetween,
  createTwoFrameBuffer, stabilizeWithTwoFrameBuffer, computeProcessPose,
} from '../utils/process-engine';
import type { BodyViewMode, WalkingEnginePose, ProcessMoodId } from '../types';

const KEYS = ['waist','neck','collar','torso','l_shoulder','r_shoulder','l_elbow','r_elbow','l_hand','r_hand',
  'l_hip','r_hip','l_knee','r_knee','l_foot','r_foot','l_toe','r_toe','y_offset','x_offset'] as const;
const views: BodyViewMode[] = ['front','sideR','threeQuarterL','back'];
const moods: ProcessMoodId[] = ['composed','exuberant','melancholic'];
const FPS = 60, dt = 1 / FPS;

const maxDiff = (a: WalkingEnginePose, b: WalkingEnginePose) =>
  Math.max(...KEYS.map(k => Math.abs((a as any)[k] - (b as any)[k])));

const ANG = KEYS.filter(k => k !== 'y_offset' && k !== 'x_offset');
let worstJerkHand = 0, worstJerkPair = '', worstOffAcc = 0;
let n = 0, worstEnd = 0, worstStart = 0, worstPop = 0, worstAcc = 0, worstOver = 0, fallFrames = 0, spikePairs = 0;
let worstOverPair = '', worstEndPair = '', worstPopPair = '', worstAccPair = '';
const durations = [0.72, 1.1, 1.6];

for (const sA of STARTER_STANCE_CATALOG) for (const sB of STARTER_STANCE_CATALOG) {
  if (sA.id === sB.id) continue;
  for (const view of views) for (const mood of moods) {
    const dur = durations[n % durations.length];
    n++;
    const A = buildProcessEndpoint(sA.id, 'composed', 'standard', view, false, 0);
    const mk = (ph: number) => buildProcessEndpoint(sB.id, mood, 'standard', view, false, ph);
    const tag = `${sA.id}->${sB.id}/${view}/${mood}/${dur}s`;

    // pure solver endpoint continuity
    worstStart = Math.max(worstStart, maxDiff(solveKinematicInBetween(A, mk(0), 0).pose, A.pose));
    const endGap = maxDiff(solveKinematicInBetween(A, mk(0), 1).pose, mk(0).pose);
    if (endGap > worstEnd) { worstEnd = endGap; worstEndPair = tag; }

    // full pipeline: solver -> pose-follow low-pass -> stabilizer
    const buf = createTwoFrameBuffer();
    let live: WalkingEnginePose = { ...A.pose };
    let prev: WalkingEnginePose | null = null, prevV: number[] | null = null;
    let overKey = '', pairKey = '', handJerk = 0, handoffPop = 0, pairAcc = 0, pairOver = 0, spike = false;
    const total = Math.round((dur + 1.0) * FPS);
    for (let f = 0; f < total; f++) {
      const time = f * dt, inTrans = time < dur;
      const ph = time * 2.0;
      const B = mk(ph);
      const target = inTrans ? solveKinematicInBetween(A, B, time / dur).pose : B.pose;
      const alpha = 1 - Math.exp(-15 * dt);
      const cand = { ...target } as any;
      for (const k of KEYS) cand[k] = (live as any)[k] + ((target as any)[k] - (live as any)[k]) * alpha;
      const st = stabilizeWithTwoFrameBuffer(buf, cand, 0, view, dt);
      live = st.pose;
      if (buf.fallDepth > 0.001 || buf.unspoolEnergy > 0.12) { fallFrames++; spike = true; }
      if (prev) {
        const v = KEYS.map(k => ((live as any)[k] - (prev as any)[k]) / dt);
        if (prevV) {
          const accA = Math.max(...v.map((x, i) => KEYS[i] === 'y_offset' || KEYS[i] === 'x_offset' ? 0 : Math.abs(x - prevV![i]) / dt)); // deg/s^2 (angles only)
          if (f > 3) pairAcc = Math.max(pairAcc, accA);
          if (Math.abs(time - dur) < 2 * dt) { if (accA > handJerk) { handJerk = accA; pairKey = KEYS[v.map((x, i) => KEYS[i] === 'y_offset' || KEYS[i] === 'x_offset' ? 0 : Math.abs(x - prevV![i]) / dt).reduce((bi, x, i, arr) => x > arr[bi] ? i : bi, 0)] + '@f' + f + ' fall=' + buf.fallDepth.toFixed(2) + ' unspool=' + buf.unspoolEnergy.toFixed(2); } }
        }
        const step = Math.max(...KEYS.map(k => Math.abs((live as any)[k] - (prev as any)[k])));
        if (Math.abs(time - dur) < 3 * dt) handoffPop = Math.max(handoffPop, step);
        prevV = v;
      }
      for (const k of ['l_elbow','r_elbow','l_knee','r_knee','l_hip','r_hip','l_shoulder','r_shoulder'] as const) {
        const lo = Math.min((A.pose as any)[k], (B.pose as any)[k]), hi = Math.max((A.pose as any)[k], (B.pose as any)[k]);
        const v = (live as any)[k];
        { const o = Math.max(v - hi, lo - v); if (o > pairOver) { pairOver = o; overKey = k + '@t=' + time.toFixed(2); } }
      }
      prev = live;
    }
    if (handJerk > worstJerkHand) { worstJerkHand = handJerk; worstJerkPair = tag; (globalThis as any).__hk = pairKey; }
    if (handoffPop > worstPop) { worstPop = handoffPop; worstPopPair = tag; }
    if (pairAcc > worstAcc) { worstAcc = pairAcc; worstAccPair = tag; }
    if (pairOver > worstOver) { worstOver = pairOver; worstOverPair = tag + ' ' + overKey; }
    if (spike) { spikePairs++; if (spikePairs <= 4) console.error('fall/unspool:', tag); }
  }
}
console.log(JSON.stringify({
  pairs: n,
  solverStartGapDeg: +worstStart.toFixed(2),
  solverEndGapDeg: +worstEnd.toFixed(2), worstEndPair,
  handoffVelocityJumpDegPerS2: Math.round(worstJerkHand), worstJerkPair, worstJerkKey: (globalThis as any).__hk,
  peakAccelDegPerS2: Math.round(worstAcc), worstAccPair,
  overshootBeyondAB_deg: +worstOver.toFixed(1), worstOverPair,
  pairsTriggeringFallOrUnspool: spikePairs, framesWithFallOrUnspool: fallFrames,
}, null, 1));
