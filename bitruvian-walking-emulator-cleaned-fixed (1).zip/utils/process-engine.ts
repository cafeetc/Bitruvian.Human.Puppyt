import {
  BodyViewMode,
  GotzHandPresetName,
  HeadTurnStep,
  MotionFeelId,
  ProcessIntensityId,
  ProcessMoodId,
  RibAnchorMode,
  WalkingEnginePose,
} from '../types';
import type { PuppytNode, PuppytPiece } from './puppyt-rig';

export const PROCESS_CENTER_X = 1257;
const DEG = Math.PI / 180;

const normDeg = (d: number): number => {
  const safe = Number.isFinite(d) ? d : 0;
  return ((((safe + 180) % 360) + 360) % 360) - 180;
};

const clampVal = (v: number, lo: number, hi: number): number => Math.max(lo, Math.min(hi, v));

const lerpVal = (a: number, b: number, t: number): number => a + (b - a) * t;

export interface BodyViewSpec {
  id: BodyViewMode;
  label: string;
  shortLabel: string;
  cue: string;
}

export const BODY_VIEW_SPECS: readonly BodyViewSpec[] = [
  { id: 'front', label: 'Front', shortLabel: 'Front', cue: 'Straight frontal orthographic view' },
  { id: 'threeQuarterR', label: '¾ Right', shortLabel: '3/4 R', cue: 'Three-quarter turn to camera right' },
  { id: 'sideR', label: 'Right Side', shortLabel: 'Side R', cue: 'True sagittal profile facing right' },
  { id: 'back', label: 'Back (3P)', shortLabel: 'Back', cue: 'Third-person rear view with reversed depth' },
  { id: 'sideL', label: 'Left Side', shortLabel: 'Side L', cue: 'True sagittal profile facing left' },
  { id: 'threeQuarterL', label: '¾ Left', shortLabel: '3/4 L', cue: 'Three-quarter turn to camera left' },
] as const;

export interface ProcessStanceSpec {
  id: string;
  label: string;
  category: string;
  cue: string;
  regime: 'standing' | 'moving';
  airborne: boolean;
  defaultRibAnchor: RibAnchorMode;
  defaultWings: boolean;
  preferredView?: BodyViewMode;
  rootOffset: [number, number];
  nodes: Record<string, number>;
  flipX?: Record<string, boolean>;
  cam: { waveform: string; phaseLag: number; breathAmp: number };
}

export const STARTER_STANCE_CATALOG: readonly ProcessStanceSpec[] = [
  {
    id: 'vitruvian',
    label: 'Vitruvian Neutral',
    category: 'Standing & Weight',
    cue: 'Symmetrical 1:1 span reference and vertical plumb line',
    regime: 'standing',
    airborne: false,
    defaultRibAnchor: 'upper',
    defaultWings: false,
    rootOffset: [0, 0],
    nodes: {
      pelvis: 0,
      hipR: 18,
      femurR: -18,
      shinR: 0,
      footR: 0,
      toeR: 0,
      hipL: -18,
      femurL: 18,
      shinL: 0,
      footL: 0,
      toeL: 0,
      humerusL: -88,
      humerusR: 88,
      forearmL: 0,
      forearmR: 0,
    },
    cam: { waveform: 'sine', phaseLag: 0.08, breathAmp: 1.6 },
  },
  {
    id: 'contrapposto',
    label: 'Contrapposto',
    category: 'Standing & Weight',
    cue: 'Support hip weight shift with counter-tilted ribcage',
    regime: 'standing',
    airborne: false,
    defaultRibAnchor: 'upper',
    defaultWings: false,
    rootOffset: [-55, 45],
    nodes: {
      pelvis: 7,
      lumbar: -7,
      thorax: -5,
      hipR: 18,
      femurR: -22,
      shinR: 4,
      footR: -7,
      toeR: 0,
      hipL: -26,
      femurL: 8,
      shinL: 18,
      footL: -16,
      toeL: 10,
    },
    cam: { waveform: 'sine', phaseLag: 0.14, breathAmp: 2.1 },
  },
  {
    id: 'wideReady',
    label: 'Wide Power',
    category: 'Standing & Weight',
    cue: 'Leonardo 1/14 splay, braced knees, double-foot lock',
    regime: 'standing',
    airborne: false,
    defaultRibAnchor: 'upper',
    defaultWings: false,
    rootOffset: [0, 220],
    nodes: {
      pelvis: 0,
      hipR: 38,
      femurR: -14,
      shinR: -24,
      footR: 0,
      toeR: 0,
      hipL: -38,
      femurL: 14,
      shinL: 24,
      footL: 0,
      toeL: 0,
    },
    cam: { waveform: 'dwell', phaseLag: 0.1, breathAmp: 2.4 },
  },
  {
    id: 'walkStride',
    label: 'Walking Stride',
    category: 'Locomotion & Action',
    cue: 'Muybridge mid-stride with contralateral arm-leg gear',
    regime: 'moving',
    airborne: false,
    defaultRibAnchor: 'upper',
    defaultWings: false,
    rootOffset: [0, 140],
    nodes: {
      pelvis: 4,
      lumbar: -3,
      thorax: 4,
      hipR: 22,
      femurR: 22,
      shinR: -24,
      footR: 8,
      toeR: -8,
      hipL: -14,
      femurL: -26,
      shinL: 22,
      footL: -12,
      toeL: 10,
      humerusL: -32,
      forearmL: -38,
      humerusR: 22,
      forearmR: 24,
    },
    cam: { waveform: 'pendulum', phaseLag: 0.22, breathAmp: 3 },
  },
  {
    id: 'sprintDrive',
    label: 'Sprint Drive',
    category: 'Locomotion & Action',
    cue: 'Steep forward torso drive, high knee, trailing push-off',
    regime: 'moving',
    airborne: false,
    defaultRibAnchor: 'upper',
    defaultWings: false,
    rootOffset: [-40, 260],
    nodes: {
      pelvis: 10,
      lumbar: 10,
      thorax: 8,
      neck: -10,
      head: -8,
      hipR: 28,
      femurR: 44,
      shinR: -82,
      footR: 14,
      toeR: -12,
      hipL: -14,
      femurL: -38,
      shinL: 44,
      footL: -24,
      toeL: 18,
      humerusL: -64,
      forearmL: -92,
      humerusR: 54,
      forearmR: 92,
    },
    cam: { waveform: 'ratchet', phaseLag: 0.26, breathAmp: 4.2 },
  },
  {
    id: 'lungeReach',
    label: 'Lunging Reach',
    category: 'Locomotion & Action',
    cue: 'Extended asymmetric split lunge with forward reach vector',
    regime: 'moving',
    airborne: false,
    defaultRibAnchor: 'upper',
    defaultWings: false,
    rootOffset: [-60, 620],
    nodes: {
      pelvis: 8,
      lumbar: 10,
      thorax: 8,
      neck: -8,
      head: -6,
      hipR: 24,
      femurR: 38,
      shinR: -68,
      footR: 0,
      toeR: 0,
      hipL: -18,
      femurL: -42,
      shinL: 24,
      footL: -24,
      toeL: 22,
      humerusR: -108,
      forearmR: -18,
      humerusL: 38,
      forearmL: -42,
    },
    cam: { waveform: 'dwell', phaseLag: 0.18, breathAmp: 2.8 },
  },
  {
    id: 'airborne',
    label: 'Airborne Leap',
    category: 'Locomotion & Action',
    cue: 'Suspended apex arc above ground plane, swept limbs',
    regime: 'moving',
    airborne: true,
    defaultRibAnchor: 'upper',
    defaultWings: false,
    rootOffset: [0, -520],
    nodes: {
      pelvis: 8,
      lumbar: 6,
      thorax: 8,
      hipR: 26,
      femurR: 44,
      shinR: -84,
      footR: 22,
      toeR: -14,
      hipL: -22,
      femurL: -38,
      shinL: 48,
      footL: -24,
      toeL: 18,
      humerusL: -134,
      forearmL: -32,
      humerusR: 128,
      forearmR: 28,
    },
    cam: { waveform: 'sine', phaseLag: 0.3, breathAmp: 3.5 },
  },
  {
    id: 'seatedPerched',
    label: 'Seated Perched',
    category: 'Seated & Grounded',
    cue: '90° hip flexion on implied plinth with balanced spine',
    regime: 'standing',
    airborne: false,
    defaultRibAnchor: 'upper',
    defaultWings: false,
    rootOffset: [0, 1280],
    nodes: {
      pelvis: -4,
      lumbar: 4,
      thorax: 4,
      neck: -4,
      head: -2,
      hipR: 44,
      femurR: 34,
      shinR: -78,
      footR: 8,
      toeR: 0,
      hipL: -44,
      femurL: -34,
      shinL: 78,
      footL: -8,
      toeL: 0,
      humerusL: -14,
      forearmL: -56,
      handL: 12,
      humerusR: 18,
      forearmR: 58,
      handR: -12,
    },
    cam: { waveform: 'sine', phaseLag: 0.12, breathAmp: 2 },
  },
  {
    id: 'kneelingPoise',
    label: 'Kneeling Poise',
    category: 'Seated & Grounded',
    cue: 'Grounded knee fulcrum, split pelvis, upright thorax',
    regime: 'standing',
    airborne: false,
    defaultRibAnchor: 'upper',
    defaultWings: false,
    rootOffset: [-30, 1240],
    nodes: {
      pelvis: 4,
      lumbar: -4,
      thorax: -3,
      hipR: 28,
      femurR: 48,
      shinR: -76,
      footR: 4,
      toeR: 0,
      hipL: -22,
      femurL: -14,
      shinL: 98,
      footL: -28,
      toeL: 16,
      humerusL: -22,
      forearmL: -48,
      humerusR: 24,
      forearmR: 36,
    },
    cam: { waveform: 'dwell', phaseLag: 0.14, breathAmp: 2.2 },
  },
  {
    id: 'deepCoil',
    label: 'Deep Crouch',
    category: 'Seated & Grounded',
    cue: 'Compressed spring coil, stacked hip-knee-ankle flexion',
    regime: 'standing',
    airborne: false,
    defaultRibAnchor: 'upper',
    defaultWings: false,
    rootOffset: [0, 1180],
    nodes: {
      pelvis: 4,
      lumbar: -12,
      thorax: -12,
      neck: 10,
      head: 8,
      hipR: 56,
      femurR: 28,
      shinR: -92,
      footR: 8,
      toeR: 0,
      hipL: -56,
      femurL: -28,
      shinL: 92,
      footL: -8,
      toeL: 0,
    },
    cam: { waveform: 'dwell', phaseLag: 0.16, breathAmp: 2.6 },
  },
  {
    id: 'dynamicTwist',
    label: 'Dynamic S-Twist',
    category: 'Dynamic & Bitruvian',
    cue: 'Diagonal S-curve line of action with rib-pelvis counter-twist',
    regime: 'standing',
    airborne: false,
    defaultRibAnchor: 'upper',
    defaultWings: false,
    rootOffset: [40, 180],
    nodes: {
      pelvis: -12,
      lumbar: 16,
      thorax: 18,
      neck: -14,
      head: -12,
      ribL: 12,
      ribR: -8,
      hipR: 28,
      femurR: -18,
      shinR: -8,
      footR: 10,
      hipL: -34,
      femurL: 4,
      shinL: 36,
      footL: -14,
      toeL: 12,
      humerusL: -98,
      forearmL: -38,
      humerusR: 36,
      forearmR: 78,
    },
    cam: { waveform: 'sine', phaseLag: 0.2, breathAmp: 3 },
  },
  {
    id: 'promethean',
    label: 'Promethean Chungus',
    category: 'Dynamic & Bitruvian',
    cue: 'Signature Bitruvian mirrored stance with Chungus rib swing',
    regime: 'standing',
    airborne: false,
    defaultRibAnchor: 'lower',
    defaultWings: true,
    rootOffset: [48.5, 162.2],
    nodes: {
      pelvis: 0.3,
      lumbar: -0.6,
      thorax: -0.1,
      neck: -0.4,
      head: 0,
      swivelL: 28.1,
      acromionL: -26.9,
      braceL: 12,
      swivelR: -28.1,
      acromionR: 26.9,
      braceR: -12,
      humerusL: -9.7,
      humerusR: 9.7,
      forearmL: -101.4,
      forearmR: 101.4,
      handL: 127.5,
      handR: -127.5,
      hipR: 57.7,
      femurR: -25.2,
      shinR: -51.3,
      footR: 24,
      hipL: -59.4,
      femurL: 36,
      shinL: 52,
      footL: -28.9,
      ribR: -40.5,
      ribL: 33.3,
    },
    cam: { waveform: 'ratchet', phaseLag: 0.15, breathAmp: 2.5 },
  },
  {
    id: 'archProfile',
    label: 'Side Archer',
    category: 'Side & Back Poise',
    cue: 'Poised side profile draw with rear-weighted stance and lifted sternum',
    regime: 'standing',
    airborne: false,
    defaultRibAnchor: 'upper',
    defaultWings: false,
    preferredView: 'sideR',
    rootOffset: [-24, 140],
    nodes: {
      pelvis: -6,
      lumbar: 10,
      thorax: 8,
      neck: -6,
      head: -5,
      swivelR: 12,
      swivelL: -16,
      acromionR: -8,
      acromionL: 10,
      humerusR: -78,
      forearmR: -18,
      handR: 8,
      humerusL: 24,
      forearmL: -72,
      handL: -12,
      hipR: -6,
      femurR: 22,
      shinR: -28,
      footR: 6,
      hipL: 6,
      femurL: -18,
      shinL: 16,
      footL: 4,
    },
    cam: { waveform: 'sine', phaseLag: 0.14, breathAmp: 1.8 },
  },
  {
    id: 'reposeProfile',
    label: 'Profile Repose',
    category: 'Side & Back Poise',
    cue: 'Editorial profile lean settled over trailing heel with relaxed arms',
    regime: 'standing',
    airborne: false,
    defaultRibAnchor: 'upper',
    defaultWings: false,
    preferredView: 'sideL',
    rootOffset: [18, 95],
    nodes: {
      pelvis: 5,
      lumbar: -6,
      thorax: -5,
      neck: 6,
      head: 5,
      humerusL: 12,
      forearmL: 34,
      handL: 10,
      humerusR: -16,
      forearmR: 26,
      handR: -8,
      hipL: 6,
      femurL: -14,
      shinL: 12,
      footL: 2,
      hipR: -4,
      femurR: 16,
      shinR: -20,
      footR: 6,
      toeR: -6,
    },
    cam: { waveform: 'sine', phaseLag: 0.12, breathAmp: 1.6 },
  },
  {
    id: 'stalkProfile',
    label: 'Profile Prowl',
    category: 'Side & Back Poise',
    cue: 'Low coiled profile center of gravity with counterbalanced trailing arm',
    regime: 'standing',
    airborne: false,
    defaultRibAnchor: 'upper',
    defaultWings: false,
    preferredView: 'sideR',
    rootOffset: [14, 480],
    nodes: {
      pelvis: 8,
      lumbar: 10,
      thorax: 11,
      neck: -14,
      head: -10,
      humerusR: 32,
      forearmR: -58,
      handR: 16,
      humerusL: -26,
      forearmL: -44,
      handL: -14,
      hipR: 18,
      femurR: 34,
      shinR: -62,
      footR: 14,
      hipL: -12,
      femurL: -32,
      shinL: 42,
      footL: -18,
      toeL: 12,
    },
    cam: { waveform: 'dwell', phaseLag: 0.16, breathAmp: 2.0 },
  },
  {
    id: 'sphinxPerch',
    label: 'Profile Perch',
    category: 'Side & Back Poise',
    cue: 'Half-seated profile perch with clean lumbar stack and rested wrists',
    regime: 'standing',
    airborne: false,
    defaultRibAnchor: 'upper',
    defaultWings: false,
    preferredView: 'sideL',
    rootOffset: [-12, 920],
    nodes: {
      pelvis: -6,
      lumbar: 9,
      thorax: 6,
      neck: -4,
      head: -4,
      humerusL: 20,
      forearmL: 52,
      handL: -14,
      humerusR: -18,
      forearmR: 46,
      handR: 12,
      hipL: 18,
      femurL: -38,
      shinL: 64,
      footL: -14,
      hipR: -18,
      femurR: 32,
      shinR: -54,
      footR: 12,
    },
    cam: { waveform: 'sine', phaseLag: 0.11, breathAmp: 1.7 },
  },
  {
    id: 'dorsalLookback',
    label: 'Back Lookback',
    category: 'Side & Back Poise',
    cue: '3rd-person dorsal contrapposto with over-shoulder cervical twist',
    regime: 'standing',
    airborne: false,
    defaultRibAnchor: 'upper',
    defaultWings: false,
    preferredView: 'back',
    rootOffset: [-28, 70],
    nodes: {
      pelvis: -8,
      lumbar: 10,
      thorax: 8,
      neck: -14,
      head: -16,
      swivelR: 10,
      swivelL: -6,
      acromionR: -8,
      acromionL: 6,
      humerusR: 22,
      forearmR: 28,
      handR: -8,
      humerusL: -14,
      forearmL: -22,
      handL: 10,
      hipR: 18,
      femurR: -12,
      shinR: 6,
      footR: -4,
      hipL: -24,
      femurL: 8,
      shinL: 18,
      footL: -12,
      toeL: 8,
    },
    cam: { waveform: 'sine', phaseLag: 0.14, breathAmp: 1.8 },
  },
  {
    id: 'sentinelBack',
    label: 'Back Sentinel',
    category: 'Side & Back Poise',
    cue: 'Squared dorsal guard framing scapulae, spine ridge, and braced heels',
    regime: 'standing',
    airborne: false,
    defaultRibAnchor: 'upper',
    defaultWings: true,
    preferredView: 'back',
    rootOffset: [0, 130],
    nodes: {
      pelvis: 0,
      lumbar: -4,
      thorax: -4,
      neck: 4,
      head: 4,
      swivelL: 16,
      swivelR: -16,
      acromionL: -14,
      acromionR: 14,
      braceL: 8,
      braceR: -8,
      humerusL: -24,
      forearmL: -36,
      handL: 16,
      humerusR: 24,
      forearmR: 36,
      handR: -16,
      hipR: 28,
      femurR: -14,
      shinR: -12,
      footR: 0,
      hipL: -28,
      femurL: 14,
      shinL: 12,
      footL: 0,
    },
    cam: { waveform: 'dwell', phaseLag: 0.12, breathAmp: 1.9 },
  },
];

export interface ProcessMoodSpec {
  id: ProcessMoodId;
  label: string;
  cue: string;
  angles: Record<string, number>;
  handL: GotzHandPresetName;
  handR: GotzHandPresetName;
  jawDeg: number;
  spineCounterWeight: number;
  clavicleFollowRatio: number;
}

export const MOOD_SPECS: readonly ProcessMoodSpec[] = [
  {
    id: 'composed',
    label: 'Composed',
    cue: 'Poised neutral axis, relaxed shoulders',
    angles: {
      lumbar: 0,
      thorax: 0,
      neck: 0,
      head: 0,
      swivelL: 2,
      swivelR: -2,
      acromionL: -2,
      acromionR: 2,
      braceL: 1,
      braceR: -1,
      humerusL: -6,
      humerusR: 6,
      forearmL: -12,
      forearmR: 12,
      handL: 4,
      handR: -4,
      ribL: 2,
      ribR: -2,
    },
    handL: 'Neutral',
    handR: 'Neutral',
    jawDeg: 0,
    spineCounterWeight: 0.58,
    clavicleFollowRatio: 0.22,
  },
  {
    id: 'heroic',
    label: 'Heroic',
    cue: 'Raised sternum, lifted chin, open shoulders',
    angles: {
      lumbar: -6,
      thorax: 7,
      neck: -3,
      head: -5,
      swivelL: 14,
      swivelR: -14,
      acromionL: -12,
      acromionR: 12,
      braceL: 6,
      braceR: -6,
      humerusL: -28,
      humerusR: 28,
      forearmL: -26,
      forearmR: 26,
      handL: 12,
      handR: -12,
      ribL: 12,
      ribR: -12,
    },
    handL: 'Fist',
    handR: 'Fist',
    jawDeg: 0,
    spineCounterWeight: 0.65,
    clavicleFollowRatio: 0.34,
  },
  {
    id: 'exuberant',
    label: 'Joyful',
    cue: 'Expansive upward reach, flared ribcage',
    angles: {
      lumbar: 5,
      thorax: -8,
      neck: -5,
      head: -9,
      swivelL: 22,
      swivelR: -22,
      acromionL: -18,
      acromionR: 18,
      braceL: 9,
      braceR: -9,
      humerusL: -124,
      humerusR: 118,
      forearmL: -22,
      forearmR: 28,
      handL: -16,
      handR: 16,
      ribL: 14,
      ribR: -14,
    },
    handL: 'Open',
    handR: 'Open',
    jawDeg: 10,
    spineCounterWeight: 0.45,
    clavicleFollowRatio: 0.42,
  },
  {
    id: 'melancholic',
    label: 'Sad',
    cue: 'Compressive slump, dropped shoulders, bowed head',
    angles: {
      lumbar: 10,
      thorax: 14,
      neck: 15,
      head: 18,
      swivelL: -14,
      swivelR: 14,
      acromionL: 14,
      acromionR: -14,
      braceL: -7,
      braceR: 7,
      humerusL: 8,
      humerusR: -8,
      forearmL: -18,
      forearmR: 18,
      handL: 14,
      handR: -14,
      ribL: -10,
      ribR: 10,
    },
    handL: 'Neutral',
    handR: 'Neutral',
    jawDeg: 3,
    spineCounterWeight: 0.25,
    clavicleFollowRatio: 0.18,
  },
  {
    id: 'guarded',
    label: 'Wary',
    cue: 'Tucked chin, raised clavicles, protective arms',
    angles: {
      lumbar: 7,
      thorax: 11,
      neck: 10,
      head: -8,
      swivelL: -22,
      swivelR: 22,
      acromionL: 12,
      acromionR: -12,
      braceL: -10,
      braceR: 10,
      humerusL: 16,
      humerusR: -22,
      forearmL: -112,
      forearmR: 106,
      handL: -18,
      handR: 18,
      ribL: -8,
      ribR: 8,
    },
    handL: 'Fist',
    handR: 'Fist',
    jawDeg: 0,
    spineCounterWeight: 0.35,
    clavicleFollowRatio: 0.28,
  },
  {
    id: 'predatory',
    label: 'Hunting',
    cue: 'Forward coiled thorax, aggressive jaw, claw tension',
    angles: {
      lumbar: 12,
      thorax: 16,
      neck: -14,
      head: -12,
      swivelL: -16,
      swivelR: 16,
      acromionL: -10,
      acromionR: 10,
      braceL: -6,
      braceR: 6,
      humerusL: -42,
      humerusR: 34,
      forearmL: -74,
      forearmR: 66,
      handL: 28,
      handR: -28,
      ribL: 10,
      ribR: -10,
    },
    handL: 'Grip',
    handR: 'Grip',
    jawDeg: 13,
    spineCounterWeight: 0.48,
    clavicleFollowRatio: 0.36,
  },
  {
    id: 'inquisitive',
    label: 'Curious',
    cue: 'Tilted skull, asymmetric shoulder poise',
    angles: {
      lumbar: -5,
      thorax: 7,
      neck: 10,
      head: 16,
      swivelL: -10,
      swivelR: 6,
      acromionL: 8,
      acromionR: -6,
      braceL: -4,
      braceR: 3,
      humerusL: -14,
      humerusR: 28,
      forearmL: -16,
      forearmR: 118,
      handL: 8,
      handR: -22,
      ribL: 4,
      ribR: -6,
    },
    handL: 'Open',
    handR: 'Pinch',
    jawDeg: 2,
    spineCounterWeight: 0.52,
    clavicleFollowRatio: 0.25,
  },
  {
    id: 'dramatic',
    label: 'Intense',
    cue: 'High-contrast S-curve spine, theatrical sweep',
    angles: {
      lumbar: -12,
      thorax: 16,
      neck: -10,
      head: -12,
      swivelL: 20,
      swivelR: -16,
      acromionL: -18,
      acromionR: 14,
      braceL: 8,
      braceR: -6,
      humerusL: -108,
      humerusR: 48,
      forearmL: -42,
      forearmR: 84,
      handL: -32,
      handR: 28,
      ribL: 16,
      ribR: -14,
    },
    handL: 'Point',
    handR: 'Open',
    jawDeg: 9,
    spineCounterWeight: 0.62,
    clavicleFollowRatio: 0.4,
  },
];

export const INTENSITY_SCALES: Record<ProcessIntensityId, number> = {
  subtle: 0.58,
  standard: 1.0,
  dramatic: 1.35,
  extreme: 1.68,
};

export interface MotionFeelPreset {
  id: MotionFeelId;
  label: string;
  params: readonly [number, number, number, number, number, number];
}

export const MOTION_FEEL_PRESETS: readonly MotionFeelPreset[] = [
  { id: 'flow', label: 'Flow', params: [0.7, 0.1, 0.2, 0, 0.8, 0] },
  { id: 'snap', label: 'Snap', params: [0.3, 0.25, 0, 0.1, 0.6, 0.2] },
  { id: 'elastic', label: 'Elastic', params: [0.4, 0.15, 0.3, 0.9, 0.25, 0] },
  { id: 'mechanical', label: 'Mechanical', params: [0.2, 0, 0.1, 0, 0.9, 0.9] },
];

export function evaluateMotionCurve(t: number, feelId: MotionFeelId): number {
  const clamped = clampVal(t, 0, 1);
  const preset = MOTION_FEEL_PRESETS.find((f) => f.id === feelId) ?? MOTION_FEEL_PRESETS[0];
  const [e, an, st, bo, da, to] = preset.params;
  const u = clampVal((clamped - st * 0.3) / Math.max(0.05, 1 - st * 0.3), 0, 1);
  let b = u + (u * u * (3 - 2 * u) - u) * e;
  if (to > 0.7) b = Math.round(b * 8) / 8;
  const bounceTerm = bo * 0.3 * Math.sin(u * Math.PI * 3) * Math.exp(-u * (1 + da * 6));
  const anticTerm = clamped < 0.2 ? -an * 0.5 * Math.sin((clamped / 0.2) * Math.PI) : 0;
  return b + bounceTerm + anticTerm;
}

/**
 * Soft angular saturation resistance (_e from Bitruvius.Process) across lumbar, thorax, & shoulder girdle.
 */
export function applySoftSpineResistance(
  id: string,
  deg: number,
  by: Record<string, PuppytNode>,
  prometheusWings: boolean
): number {
  const norm = normDeg(deg);
  const txAng = by.thorax ? Number(by.thorax.ang || 0) : 0;
  let ref = 0;
  let thresh = 180;
  let headroom = 0;

  if (id === 'swivelL' || id === 'swivelR') {
    ref = txAng;
    thresh = 16;
    headroom = prometheusWings ? 26 : 12;
  } else if (id === 'braceL' || id === 'braceR') {
    thresh = 8;
    headroom = prometheusWings ? 28 : 6;
  } else if (id === 'acromionL' || id === 'acromionR') {
    thresh = 22;
    headroom = prometheusWings ? 38 : 13;
  } else if (id === 'lumbar') {
    thresh = 34;
    headroom = 28;
  } else if (id === 'thorax') {
    thresh = 30;
    headroom = 26;
  } else {
    return norm;
  }

  const rel = normDeg(norm - ref);
  const mag = Math.abs(rel);
  if (mag <= thresh || headroom <= 0.1) return norm;
  const sign = rel >= 0 ? 1 : -1;
  const excess = mag - thresh;
  const x = Math.min(1, excess / headroom);
  const smooth = x * x * (3 - 2 * x);
  const damped = prometheusWings
    ? headroom * Math.tanh(excess / (headroom * 0.95))
    : headroom * (0.68 * Math.tanh(excess / headroom) + 0.32 * smooth * (excess / Math.max(excess, headroom)));
  return normDeg(ref + sign * (thresh + Math.min(headroom, damped)));
}

/**
 * Pelvic-Lumbar-Thorax compensatory counter-rotation (Dt from Bitruvius.Process).
 */
export function applySpineCompensatoryCounterbalance(
  by: Record<string, PuppytNode>,
  spineCounterWeight = 0.55,
  clavicleFollowRatio = 0.25,
  overrideHeadPitch = false
): void {
  const pe = by.pelvis;
  const lu = by.lumbar;
  const th = by.thorax;
  const nk = by.neck;
  const hd = by.head;

  if (pe && lu && th) {
    const pelAng = normDeg(pe.ang);
    lu.ang = normDeg(lu.ang - pelAng * spineCounterWeight * 0.48);
    th.ang = normDeg(th.ang - pelAng * spineCounterWeight * 0.34);
    if (!overrideHeadPitch && nk && hd) {
      const spineSum = normDeg(pe.ang) + normDeg(lu.ang) + normDeg(th.ang);
      nk.ang = normDeg(nk.ang - spineSum * 0.28);
      hd.ang = normDeg(hd.ang - spineSum * 0.22);
    }
  }

  for (const s of ['L', 'R'] as const) {
    const hu = by['humerus' + s];
    const ac = by['acromion' + s];
    const sw = by['swivel' + s];
    if (!hu || !ac || !sw) continue;
    const raise = s === 'L' ? Math.max(0, -hu.ang - 25) : Math.max(0, hu.ang - 25);
    if (raise > 0) {
      const sideSign = s === 'L' ? -1 : 1;
      ac.ang = normDeg(ac.ang + sideSign * raise * clavicleFollowRatio * 0.26);
      sw.ang = normDeg(sw.ang - sideSign * raise * clavicleFollowRatio * 0.16);
    }
  }
}

/**
 * Applies true 6-angle lateral pivot & sprite geometry offsets (xe from Bitruvius.Process).
 * Fully idempotent using baseRest / aimBaseFrom / restBox.x.
 */
export interface BodyViewShifts {
  armR: number; armL: number;
  legR: number; legL: number;
  ribR: number; ribL: number;
  swivR: number; swivL: number;
}

const ZERO_SHIFTS: BodyViewShifts = { armR: 0, armL: 0, legR: 0, legL: 0, ribR: 0, ribL: 0, swivR: 0, swivL: 0 };

/** Pure lateral pivot shifts (stage units) that turn the front-view rig into the requested body view. */
export function computeBodyViewShifts(by: Record<string, PuppytNode>, bodyView: BodyViewMode): BodyViewShifts {
  const baseAcR = by.acromionR?.baseRest?.[0] ?? 688;
  const baseAcL = by.acromionL?.baseRest?.[0] ?? 1815;
  const baseFemR = by.femurR?.baseRest?.[0] ?? 990;
  const baseFemL = by.femurL?.baseRest?.[0] ?? 1521;
  const baseSwivR = by.swivelTipR?.baseRest?.[0] ?? 483;
  const baseSwivL = by.swivelTipL?.baseRest?.[0] ?? 2031;
  const C = PROCESS_CENTER_X;

  if (bodyView === 'threeQuarterR') {
    return {
      armR: C + (baseAcR - C) * 0.78 + 30 - baseAcR,
      armL: C + (baseAcL - C) * 0.42 + 12 - baseAcL,
      legR: C + (baseFemR - C) * 0.8 + 26 - baseFemR,
      legL: C + (baseFemL - C) * 0.46 + 10 - baseFemL,
      swivR: C + (baseSwivR - C) * 0.78 + 30 - baseSwivR,
      swivL: C + (baseSwivL - C) * 0.42 + 12 - baseSwivL,
      ribR: 26,
      ribL: -42,
    };
  }
  if (bodyView === 'threeQuarterL') {
    return {
      armL: C + (baseAcL - C) * 0.78 - 30 - baseAcL,
      armR: C + (baseAcR - C) * 0.42 - 12 - baseAcR,
      legL: C + (baseFemL - C) * 0.8 - 26 - baseFemL,
      legR: C + (baseFemR - C) * 0.46 - 10 - baseFemR,
      swivL: C + (baseSwivL - C) * 0.78 - 30 - baseSwivL,
      swivR: C + (baseSwivR - C) * 0.42 - 12 - baseSwivR,
      ribL: -26,
      ribR: 42,
    };
  }
  if (bodyView === 'sideR') return { ...ZERO_SHIFTS, legR: 18, legL: 12, ribR: 26, ribL: -26 };
  if (bodyView === 'sideL') return { ...ZERO_SHIFTS, legL: -18, legR: -12, ribL: -26, ribR: 26 };
  return { ...ZERO_SHIFTS };
}

/**
 * Continuity state for body turns. The shifts above are a step function of the selected view; applying them
 * directly teleports arms/legs/ribs (up to ~100 stage units) in a single frame. This eases the *applied* shifts
 * toward the target every frame (retarget-safe: no restart, no pop) and delays the discrete mirror flags
 * until the turn is past its midpoint so the flip happens while the limbs are mid-glide.
 */
export interface BodyViewShiftState {
  current: BodyViewShifts | null;
  velocity: BodyViewShifts | null;
  anchor: BodyViewShifts | null;
  targetView: BodyViewMode | null;
  flipView: BodyViewMode | null;
}

export function createBodyViewShiftState(): BodyViewShiftState {
  return { current: null, velocity: null, anchor: null, targetView: null, flipView: null };
}

const SHIFT_KEYS = Object.keys(ZERO_SHIFTS) as Array<keyof BodyViewShifts>;
const shiftDist = (a: BodyViewShifts, b: BodyViewShifts): number =>
  SHIFT_KEYS.reduce((m, k) => Math.max(m, Math.abs(a[k] - b[k])), 0);

export function stepBodyViewShifts(
  state: BodyViewShiftState,
  target: BodyViewShifts,
  view: BodyViewMode,
  dt: number,
  omega = 7.5
): { shifts: BodyViewShifts; flipView: BodyViewMode } {
  if (!state.current || !state.velocity) {
    state.current = { ...target };
    state.velocity = { ...ZERO_SHIFTS };
    state.anchor = { ...target };
    state.targetView = view;
    state.flipView = view;
    return { shifts: state.current, flipView: view };
  }
  if (state.targetView !== view) {
    state.targetView = view;
    state.anchor = { ...state.current };
  }
  // Exact critically-damped spring step: starts from zero velocity (no kick), never overshoots, retarget-safe
  // because position AND velocity carry over when the view changes mid-turn.
  const h = clampVal(dt, 0, 0.1);
  const decay = Math.exp(-omega * h);
  const next = { ...state.current };
  const vel = { ...state.velocity };
  for (const k of SHIFT_KEYS) {
    const d = next[k] - target[k];
    const v = vel[k];
    const tmp = (v + omega * d) * h;
    next[k] = target[k] + (d + tmp) * decay;
    vel[k] = (v - omega * tmp) * decay;
    if (Math.abs(next[k] - target[k]) < 0.02 && Math.abs(vel[k]) < 0.5) {
      next[k] = target[k];
      vel[k] = 0;
    }
  }
  state.current = next;
  state.velocity = vel;
  const total = Math.max(1e-6, shiftDist(state.anchor ?? next, target));
  const progress = 1 - shiftDist(next, target) / total;
  if (state.flipView !== view && (progress >= 0.5 || total < 1)) state.flipView = view;
  return { shifts: next, flipView: state.flipView ?? view };
}

export function applyBodyViewPivots(
  nodes: PuppytNode[],
  by: Record<string, PuppytNode>,
  bodyView: BodyViewMode,
  shiftsOverride?: BodyViewShifts
): void {
  const rightArmIds = ['acromionR', 'humerusR', 'forearmR', 'handR', 'thumbR', 'thumbTipR', 'fingerR', 'fingerTipR'];
  const leftArmIds = ['acromionL', 'humerusL', 'forearmL', 'handL', 'thumbL', 'thumbTipL', 'fingerL', 'fingerTipL'];
  const rightLegIds = ['femurR', 'shinR', 'footR', 'toeBallR', 'toeR'];
  const leftLegIds = ['femurL', 'shinL', 'footL', 'toeBallL', 'toeL'];

  const sh = shiftsOverride ?? computeBodyViewShifts(by, bodyView);
  const armShiftR = sh.armR;
  const armShiftL = sh.armL;

  const dxMap: Record<string, number> = {};
  for (const id of rightArmIds) dxMap[id] = sh.armR;
  for (const id of leftArmIds) dxMap[id] = sh.armL;
  for (const id of rightLegIds) dxMap[id] = sh.legR;
  for (const id of leftLegIds) dxMap[id] = sh.legL;
  dxMap.swivelTipR = sh.swivR;
  dxMap.swivelTipL = sh.swivL;
  dxMap.ribR = sh.ribR;
  dxMap.ribL = sh.ribL;

  for (const node of nodes) {
    const baseRest = node.baseRest ?? node.rest;
    const dx = dxMap[node.id] ?? 0;
    node.rest = [baseRest[0] + dx, baseRest[1]];
    if (node.id !== 'wingL' && node.id !== 'wingR') {
      node.piv = [baseRest[0] + dx, baseRest[1]];
    }
    if (node.aim && node.aimBaseFrom) {
      const aimDx = node.id === 'braceR' ? armShiftR : node.id === 'braceL' ? armShiftL : 0;
      node.aim.from = [node.aimBaseFrom[0] + aimDx, node.aimBaseFrom[1]];
    }
    for (const p of node.pieces) {
      const baseX = p.restBox ? p.restBox.x : p.x;
      p.x = baseX + dx;
    }
  }
}

export function applyBodyViewRibShifts(
  by: Record<string, PuppytNode>,
  bodyView: BodyViewMode,
  shiftsOverride?: BodyViewShifts
): void {
  const sh = shiftsOverride ?? computeBodyViewShifts(by, bodyView);
  const ribShiftR = sh.ribR;
  const ribShiftL = sh.ribL;
  if (ribShiftR && by.ribR) {
    by.ribR.piv = [by.ribR.piv[0] + ribShiftR, by.ribR.piv[1]];
    by.ribR.rest = [by.ribR.piv[0], by.ribR.piv[1]];
  }
  if (ribShiftL && by.ribL) {
    by.ribL.piv = [by.ribL.piv[0] + ribShiftL, by.ribL.piv[1]];
    by.ribL.rest = [by.ribL.piv[0], by.ribL.piv[1]];
  }
}

export interface BodyViewPoseOffsets {
  angles: Record<string, number>;
  flipX: Record<string, boolean>;
}

/**
 * Profile & 3/4 joint orientation offsets + mirrored rib/hip/femur flipX flags (qe from Bitruvius.Process).
 */
export function getBodyViewPoseOffsets(
  bodyView: BodyViewMode,
  sideArmsFavorOpposite = false
): BodyViewPoseOffsets {
  if (bodyView === 'front') {
    return {
      angles: {},
      flipX: { ribR: false, ribL: false, hipR: false, hipL: false, femurR: false, femurL: false },
    };
  }
  if (bodyView === 'back') {
    // Refined 3rd-person dorsal poise: broadens scapular frame subtly and grounds stance width
    return {
      angles: {
        swivelL: 5,
        swivelR: -5,
        acromionL: -4,
        acromionR: 4,
        braceL: 2,
        braceR: -2,
        humerusL: -4,
        humerusR: 4,
      },
      flipX: { ribR: false, ribL: false, hipR: false, hipL: false, femurR: false, femurL: false },
    };
  }
  if (bodyView === 'threeQuarterR') {
    return {
      angles: {
        pelvis: -2,
        lumbar: 4,
        thorax: 5,
        neck: 3,
        head: 4,
        ribR: 7,
        ribL: 5,
        swivelR: 10,
        swivelL: -16,
        acromionR: -6,
        acromionL: 12,
        braceR: -4,
        braceL: -4,
        humerusR: 10,
        forearmR: 20,
        handR: -6,
        humerusL: -12,
        forearmL: -18,
        handL: 6,
        hipR: -4,
        hipL: -4,
        femurR: -8,
        shinR: 12,
        footR: -4,
        femurL: 10,
        shinL: -6,
        footL: 6,
      },
      flipX: { ribR: false, ribL: false, hipR: false, hipL: false, femurR: false, femurL: false },
    };
  }
  if (bodyView === 'threeQuarterL') {
    return {
      angles: {
        pelvis: 2,
        lumbar: -4,
        thorax: -5,
        neck: -3,
        head: -4,
        ribL: -7,
        ribR: -5,
        swivelL: -10,
        swivelR: 16,
        acromionL: 6,
        acromionR: -12,
        braceL: 4,
        braceR: 4,
        humerusL: -10,
        forearmL: -20,
        handL: 6,
        humerusR: 12,
        forearmR: 18,
        handR: -6,
        hipL: 4,
        hipR: 4,
        femurL: 8,
        shinL: -12,
        footL: 4,
        femurR: -10,
        shinR: 6,
        footR: -6,
      },
      flipX: { ribR: false, ribL: false, hipR: false, hipL: false, femurR: false, femurL: false },
    };
  }
  if (bodyView === 'sideR') {
    const swR = sideArmsFavorOpposite ? 31 : 23;
    const swL = sideArmsFavorOpposite ? -31 : -24;
    const acR = sideArmsFavorOpposite ? -23 : -17;
    const acL = sideArmsFavorOpposite ? 23 : 18;
    const armBias = sideArmsFavorOpposite ? -5 : 3;
    return {
      angles: {
        pelvis: -4,
        hipR: -5,
        hipL: 5,
        femurR: 15,
        shinR: -22,
        footR: 7,
        femurL: 12,
        shinL: 14,
        footL: -10,
        lumbar: 7,
        thorax: 8,
        ribR: 6,
        ribL: 8,
        neck: 5,
        head: 4,
        swivelR: swR,
        swivelL: swL,
        acromionR: acR,
        acromionL: acL,
        braceR: -6,
        braceL: 6,
        humerusR: -18 + armBias,
        forearmR: -28,
        handR: -6,
        humerusL: 12 - armBias,
        forearmL: -22,
        handL: 6,
      },
      flipX: { ribR: true, ribL: false, hipR: false, hipL: true, femurR: true, femurL: true },
    };
  }

  // sideL
  const swL = sideArmsFavorOpposite ? -31 : -23;
  const swR = sideArmsFavorOpposite ? 31 : 24;
  const acL = sideArmsFavorOpposite ? 23 : 17;
  const acR = sideArmsFavorOpposite ? -23 : -18;
  const armBias = sideArmsFavorOpposite ? 5 : -3;
  return {
    angles: {
      pelvis: 4,
      hipL: 5,
      hipR: -5,
      femurL: -15,
      shinL: 22,
      footL: -7,
      femurR: -12,
      shinR: -14,
      footR: 10,
      lumbar: -7,
      thorax: -8,
      ribL: -6,
      ribR: -8,
      neck: -5,
      head: -4,
      swivelL: swL,
      swivelR: swR,
      acromionL: acL,
      acromionR: acR,
      braceL: 6,
      braceR: -6,
      humerusL: 18 + armBias,
      forearmL: 28,
      handL: 6,
      humerusR: -12 - armBias,
      forearmR: 22,
      handR: -6,
    },
    flipX: { ribL: true, ribR: false, hipL: false, hipR: true, femurR: true, femurL: true },
  };
}

const DORSAL_BACKVIEW_PRIORITY = new Set([
  'Upperspine',
  'Backshoulder',
  'Shoulderswivel',
  'V',
]);

/**
 * Deterministic Z-ordering for Front, Back (3rd-person dorsal priority), 3/4 R/L, and Side R/L.
 * Smaller `i` sorts toward the end of `pieces` (rendered ON TOP).
 * Backshoulder (`p.wing`) planes remain locked per view so wings/scapulae never swap randomly.
 */
export function sortPiecesForBodyView(
  pieces: PuppytPiece[],
  bodyView: BodyViewMode = 'front',
  wingPop = false
): void {
  const turnRight = bodyView === 'threeQuarterR' || bodyView === 'sideR';
  const turnLeft = bodyView === 'threeQuarterL' || bodyView === 'sideL';

  for (const p of pieces) {
    const base = p.i0 ?? p.i;
    const nodeId = p.node?.id ?? '';
    const name = p.name;

    if (bodyView === 'back') {
      if (p.wing && p.node) {
        // Locked dorsal wing/scapula plane just beneath spine column (1..3) and above anterior ribs (32+)
        p.i = wingPop ? (p.node.id === 'braceR' ? 4.1 : 4.3) : p.node.id === 'braceR' ? 4.5 : 4.7;
      } else if (DORSAL_BACKVIEW_PRIORITY.has(name)) {
        p.i = Math.max(0.5, Math.min(3.2, base * 0.2));
      } else if (
        name === 'Ribcage' ||
        name === 'Neckring' ||
        name === 'Shouldertendon' ||
        name === 'Shoulderbone'
      ) {
        p.i = 32 + base * 0.1;
      } else {
        p.i = base;
      }
      continue;
    }

    if (!turnRight && !turnLeft) {
      // Front view: keep BOTH Backshoulder wings consistently behind anterior Ribcage (ribL=32, ribR=23)
      if (p.wing && p.node) {
        p.i = wingPop ? (p.node.id === 'braceR' ? 32.4 : 32.8) : p.node.id === 'braceR' ? 33.2 : 33.6;
      } else {
        p.i = base;
      }
      continue;
    }

    const nearSide = turnRight ? 'R' : 'L';
    const farSide = turnRight ? 'L' : 'R';
    const side = nodeId.endsWith('L') ? 'L' : nodeId.endsWith('R') ? 'R' : 'C';

    if (side === 'C') {
      if (nodeId === 'lumbar') p.i = 9;
      else if (nodeId === 'head') p.i = 11;
      else if (nodeId === 'neck') p.i = base === 12 ? 12 : 14;
      else if (nodeId === 'thorax') p.i = name === 'Neckring' ? 16 : 15;
      else p.i = base;
      continue;
    }

    if (side === nearSide) {
      if (nodeId.startsWith('hand')) p.i = 1.6;
      else if (nodeId.startsWith('forearm')) p.i = name === 'Radius' ? 1.8 : 2.1;
      else if (nodeId.startsWith('humerus')) p.i = 2.5;
      else if (nodeId.startsWith('acromion')) p.i = 3;
      else if (nodeId.startsWith('brace') && !p.wing) p.i = 3.5;
      else if (nodeId.startsWith('foot')) p.i = 4;
      else if (nodeId.startsWith('shin')) p.i = name === 'Fibula' ? 4.2 : 4.4;
      else if (nodeId.startsWith('femur')) p.i = 4.6;
      else if (nodeId.startsWith('hip')) p.i = 5;
      else if (nodeId.startsWith('rib')) p.i = 6;
      else if (nodeId.startsWith('swivel')) p.i = 7;
      // Near-side Backshoulder sits behind torso/rib/lumbar (6..15) so it never jumps over chest/head
      else if (p.wing) p.i = wingPop ? 16.2 : 16.5;
      else p.i = base;
    } else if (side === farSide) {
      if (nodeId.startsWith('hip')) p.i = 18;
      else if (nodeId.startsWith('foot')) p.i = 19;
      else if (nodeId.startsWith('shin')) p.i = name === 'Fibula' ? 19.2 : 19.4;
      else if (nodeId.startsWith('femur')) p.i = 19.6;
      else if (nodeId.startsWith('rib')) p.i = 21;
      else if (nodeId.startsWith('swivel')) p.i = 22;
      else if (nodeId.startsWith('acromion')) p.i = 23.5;
      else if (nodeId.startsWith('brace') && !p.wing) p.i = 24;
      else if (p.wing) p.i = wingPop ? 24.4 : 24.8;
      else if (nodeId.startsWith('humerus')) p.i = 25;
      else if (nodeId.startsWith('forearm')) p.i = name === 'Radius' ? 25.5 : 26;
      else if (nodeId.startsWith('hand')) p.i = 26.5;
      else p.i = base;
    }
  }

  pieces.sort((a, b) => b.i - a.i || (b.i0 ?? 0) - (a.i0 ?? 0));
}

export function getHeadTurnStepForBodyView(
  bodyView: BodyViewMode,
  mood: ProcessMoodId = 'composed'
): HeadTurnStep {
  if (bodyView === 'back') return 2;
  if (bodyView === 'sideR') return 1;
  if (bodyView === 'sideL') return 3;
  if (bodyView === 'threeQuarterR') return mood === 'inquisitive' || mood === 'guarded' ? 0 : 1;
  if (bodyView === 'threeQuarterL') return mood === 'inquisitive' || mood === 'guarded' ? 0 : 3;
  return 0;
}

export interface ProcessPoseOptions {
  stanceId: string;
  moodId: ProcessMoodId;
  intensityId: ProcessIntensityId;
  bodyView: BodyViewMode;
  sideArmsFavorOpposite: boolean;
  breathPhase: number;
  perspectiveStrength?: number;
}

export interface ProcessPoseOutput {
  pose: WalkingEnginePose;
  lumbarTwist: number;
  handPresetL: GotzHandPresetName;
  handPresetR: GotzHandPresetName;
  ribAnchor: RibAnchorMode;
  prometheusWings: boolean;
  isGrounded: boolean;
  jawDeg: number;
  stanceLabel: string;
  moodLabel: string;
  nodeFlipX: Record<string, boolean>;
}

/**
 * Synthesizes an idle / pose-to-pose WalkingEnginePose from the Bitruvius.Process catalog + subtle breathing.
 */
/**
 * Soft joint-range ceiling: identity up to `knee * limit`, then a tanh roll-off that asymptotes at `limit`.
 * Identity below the knee is what makes it idempotent for poses that already fit the envelope
 * (the old double soft-cap re-compressed deliberate poses every frame and read that as "tension").
 */
export const softCeiling = (val: number, limit: number, knee = 0.9): number => {
  const abs = Math.abs(val);
  const k = limit * knee;
  if (abs <= k) return val;
  const head = Math.max(1e-6, limit - k);
  return Math.sign(val) * (k + head * Math.tanh((abs - k) / head));
};

/** Generated poses are fitted to this fraction of each joint's friction limit so the stabilizer never has to fight them. */
const GENERATOR_ENVELOPE = 0.84;

export function computeProcessPose(opts: ProcessPoseOptions): ProcessPoseOutput {
  const stance =
    STARTER_STANCE_CATALOG.find((s) => s.id === opts.stanceId) ?? STARTER_STANCE_CATALOG[1];
  const mood = MOOD_SPECS.find((m) => m.id === opts.moodId) ?? MOOD_SPECS[0];
  const inten = INTENSITY_SCALES[opts.intensityId] ?? 1.0;
  const isPromethean = stance.id === 'promethean';
  const isSideView = opts.bodyView === 'sideR' || opts.bodyView === 'sideL';

  // Build base node angle map matching applyPoseToPuppytRig conventions
  const sn = stance.nodes;
  const viewOffsets = getBodyViewPoseOffsets(opts.bodyView, opts.sideArmsFavorOpposite);
  const viewBlend = isPromethean ? 0.35 : 0.76;
  const moodScale = isPromethean ? 0.42 * inten : inten;

  const angleOf = (key: string): number => {
    const base = sn[key] ?? 0;
    const va = viewOffsets.angles[key] ?? 0;
    const ma = mood.angles[key] ?? 0;
    const viewPart = isSideView && (key === 'ribR' || key === 'ribL' || key === 'swivelR' || key === 'swivelL' || key === 'acromionR' || key === 'acromionL')
      ? va + base * 0.16
      : base + va * viewBlend;
    const moodPart =
      stance.id === 'vitruvian' && (key === 'humerusL' || key === 'humerusR' || key === 'forearmL' || key === 'forearmR')
        ? ma * 0.18 * inten
        : ma * moodScale;
    return viewPart + moodPart;
  };

  // Muted, slow idle breathing wave so ribs & thorax stay calm without bouncing
  const cam = stance.cam;
  const breathRaw = Math.sin(opts.breathPhase * 0.42);
  const breathLag = Math.sin(opts.breathPhase * 0.42 - cam.phaseLag * Math.PI);
  const breathAmp = cam.breathAmp * 0.26;

  const pelvis = angleOf('pelvis');
  const lumbar = angleOf('lumbar') - pelvis * mood.spineCounterWeight * 0.48 + breathRaw * 0.38 * breathAmp;
  const torso = angleOf('thorax') - pelvis * mood.spineCounterWeight * 0.34 - breathRaw * 0.42 * breathAmp;
  const spineSum = pelvis + lumbar + torso;
  const collar = angleOf('neck') - spineSum * 0.24 - breathLag * 0.28 * breathAmp;
  const neck = angleOf('head') - spineSum * 0.18 + breathLag * 0.22 * breathAmp;

  // Merge pelvis + lumbar into WalkingEnginePose waist / lumbarTwist
  const waist = pelvis * 0.6 + lumbar * 0.45;
  const lumbarTwist = lumbar * 0.55;

  // Map Process hip+femur split cleanly into WalkingEnginePose l_hip / r_hip
  const hipL = angleOf('hipL') + angleOf('femurL');
  const hipR = angleOf('hipR') + angleOf('femurR');

  const stageScale = 0.232;
  const xOffset = (stance.rootOffset[0] ?? 0) * stageScale;
  const yOffset = (stance.rootOffset[1] ?? 0) * stageScale + breathRaw * 0.3 * breathAmp;

  // Intensity/mood scaling can push targets past +-180deg, where the rig wraps the angle onto the OPPOSITE side
  // of the body. Fit every joint into its friction envelope (monotonic, sign-preserving) before it leaves the generator.
  const fit = (key: keyof typeof JOINT_FRICTION_LIMITS, v: number): number => {
    const cfg = JOINT_FRICTION_LIMITS[key];
    return cfg ? softCeiling(v, cfg.maxAbs * GENERATOR_ENVELOPE) : v;
  };

  return {
    pose: {
      waist: fit('waist', waist),
      torso: fit('torso', torso),
      collar: fit('collar', collar),
      neck: fit('neck', neck),
      l_shoulder: fit('l_shoulder', angleOf('humerusL') - breathLag * 0.45 * breathAmp),
      r_shoulder: fit('r_shoulder', angleOf('humerusR') + breathLag * 0.45 * breathAmp),
      l_elbow: fit('l_elbow', angleOf('forearmL') + breathLag * 0.25 * breathAmp),
      r_elbow: fit('r_elbow', angleOf('forearmR') - breathLag * 0.25 * breathAmp),
      l_hand: fit('l_hand', angleOf('handL')),
      r_hand: fit('r_hand', angleOf('handR')),
      l_hip: fit('l_hip', hipL),
      r_hip: fit('r_hip', hipR),
      l_knee: fit('l_knee', angleOf('shinL')),
      r_knee: fit('r_knee', angleOf('shinR')),
      l_foot: fit('l_foot', angleOf('footL')),
      r_foot: fit('r_foot', angleOf('footR')),
      l_toe: fit('l_toe', angleOf('toeL')),
      r_toe: fit('r_toe', angleOf('toeR')),
      stride_phase: breathRaw,
      x_offset: xOffset,
      y_offset: yOffset,
    },
    lumbarTwist,
    handPresetL: mood.handL,
    handPresetR: mood.handR,
    ribAnchor: stance.defaultRibAnchor,
    prometheusWings: stance.defaultWings,
    isGrounded: !stance.airborne,
    jawDeg: mood.jawDeg * inten,
    stanceLabel: stance.label,
    moodLabel: mood.label,
    nodeFlipX: viewOffsets.flipX,
  };
}

// ============================================================================
// shyte.happyns ENGINE · REACTIVE UNSPOOL & ZERO-TENSION TWO-FRAME CONTINUITY
// Converts common kinematic tensions (limit-wall binding, spine torsion shear,
// foot-lane crowding, and sudden step spikes) into smooth downstream "unspooling"
// rather than hard stopping, snap-backs, or high-frequency limit chatter.
// ============================================================================

export const SHYTE_HAPPYNS_ENGINE_ID = 'shyte.happyns' as const;

export interface BufferedFrameSnapshot {
  pose: WalkingEnginePose;
  lumbarComp: number;
  footGapX: number;
}

export interface TwoFramePhysicsBuffer {
  f2: BufferedFrameSnapshot | null;
  f1: BufferedFrameSnapshot | null;
  lastSettledFootGapX: number;
  fallDepth: number;       // 0..1 cushioned yield depth when a balance break happens
  fallHoldTimer: number;   // brief moment absorbing weight at bottom of stumble/fall
  fallLeanSign: number;    // directional lean (-1..1) of the stumble/recovery
  unspoolEnergy: number;   // 0..1 reactive slack unspooling when tension builds
  unspoolSlack: number;    // signed angular release passed smoothly to distal limbs
  smoothedFootGapX: number;
}

export function createTwoFrameBuffer(): TwoFramePhysicsBuffer {
  return {
    f2: null,
    f1: null,
    lastSettledFootGapX: 110,
    fallDepth: 0,
    fallHoldTimer: 0,
    fallLeanSign: 1,
    unspoolEnergy: 0,
    unspoolSlack: 0,
    smoothedFootGapX: 110,
  };
}

export function resetTwoFrameBuffer(buf: TwoFramePhysicsBuffer): void {
  buf.f2 = null;
  buf.f1 = null;
  buf.fallDepth = 0;
  buf.fallHoldTimer = 0;
  buf.unspoolEnergy = 0;
  buf.unspoolSlack = 0;
}

export function recordSettledFootGap(buf: TwoFramePhysicsBuffer, lFootX: number, rFootX: number): void {
  const gap = Math.abs(lFootX - rFootX);
  if (Number.isFinite(gap)) {
    buf.lastSettledFootGapX = gap;
  }
}

const JOINT_FRICTION_LIMITS: Record<string, { maxAbs: number; maxStep: number }> = {
  waist: { maxAbs: 62, maxStep: 12 },
  torso: { maxAbs: 60, maxStep: 12 },
  collar: { maxAbs: 48, maxStep: 13 },
  neck: { maxAbs: 58, maxStep: 14 },
  l_shoulder: { maxAbs: 165, maxStep: 24 },
  r_shoulder: { maxAbs: 165, maxStep: 24 },
  l_elbow: { maxAbs: 148, maxStep: 26 },
  r_elbow: { maxAbs: 148, maxStep: 26 },
  l_hand: { maxAbs: 160, maxStep: 28 },
  r_hand: { maxAbs: 160, maxStep: 28 },
  l_hip: { maxAbs: 98, maxStep: 19 },
  r_hip: { maxAbs: 98, maxStep: 19 },
  l_knee: { maxAbs: 140, maxStep: 24 },
  r_knee: { maxAbs: 140, maxStep: 24 },
  l_foot: { maxAbs: 70, maxStep: 20 },
  r_foot: { maxAbs: 70, maxStep: 20 },
  l_toe: { maxAbs: 62, maxStep: 20 },
  r_toe: { maxAbs: 62, maxStep: 20 },
};

const BUFFERED_ANGLE_KEYS = Object.keys(JOINT_FRICTION_LIMITS) as Array<keyof WalkingEnginePose>;

const softCapSigned = (val: number, limit: number): number => {
  const abs = Math.abs(val);
  if (abs <= limit * 0.72) return val;
  const excess = abs - limit * 0.72;
  const headroom = limit * 0.36;
  return Math.sign(val) * (limit * 0.72 + headroom * Math.tanh(excess / headroom));
};

export function stabilizeWithTwoFrameBuffer(
  buf: TwoFramePhysicsBuffer,
  candidatePose: WalkingEnginePose,
  candidateLumbarComp: number,
  bodyView: BodyViewMode,
  dt: number,
  opts: { allowHighEnergy?: boolean; isBackView?: boolean } = {}
): { pose: WalkingEnginePose; lumbarComp: number } {
  const gap = buf.lastSettledFootGapX;
  buf.smoothedFootGapX = lerpVal(buf.smoothedFootGapX, gap, 1 - Math.exp(-9 * dt));

  if (!buf.f1 || !buf.f2) {
    const seedPose = { ...candidatePose };
    buf.f2 = buf.f1 ?? { pose: seedPose, lumbarComp: candidateLumbarComp, footGapX: buf.smoothedFootGapX };
    buf.f1 = { pose: seedPose, lumbarComp: candidateLumbarComp, footGapX: buf.smoothedFootGapX };
    return { pose: seedPose, lumbarComp: candidateLumbarComp };
  }

  const f1 = buf.f1;
  const dtScale = clampVal(dt / 0.0167, 0.55, 2.0);
  const energyMult = opts.allowHighEnergy ? 1.25 : 1.0;

  const outPose: WalkingEnginePose = { ...candidatePose };
  let outLumbar = candidateLumbarComp;
  let peakShock = 0;
  let limitTension = 0;
  let dominantTensionDir = 0;

  for (const key of BUFFERED_ANGLE_KEYS) {
    const cfg = JOINT_FRICTION_LIMITS[key as string];
    const cVal = Number.isFinite(candidatePose[key]) ? candidatePose[key] : 0;
    const p1 = f1.pose[key];
    const v1 = cVal - p1;

    const maxAbs = cfg.maxAbs * energyMult;
    const maxStep = cfg.maxStep * dtScale * energyMult;

    // BREAK-NOTE [BUFFER-JOINT-DELTA]: Pure passive velocity saturation (no stale v0 re-injection
    // so reversing direction never rings or shakes).
    let smoothedDelta = v1;
    if (Math.abs(v1) > maxStep * 0.8) {
      const shock = Math.abs(v1) / Math.max(1, maxStep);
      if (shock > peakShock) peakShock = shock;
      smoothedDelta = softCapSigned(v1, maxStep);
    }

    const easedVal = p1 + smoothedDelta;
    // BREAK-NOTE [BUFFER-SOFT-CEILING]: Cushion joint range ceiling and record excess pressure as unspool tension.
    const saturationRatio = Math.abs(easedVal) / Math.max(1, maxAbs);
    if (saturationRatio > 0.9) {
      limitTension = Math.max(limitTension, clampVal((saturationRatio - 0.9) * 4.2, 0, 1));
      dominantTensionDir += Math.sign(easedVal) * (saturationRatio - 0.9);
    }
    outPose[key] = softCeiling(easedVal, maxAbs);
  }

  // BREAK-NOTE [SPINE-TORSION-SHEAR]: Measure pelvis-lumbar-thorax twist binding and gently unspool shear.
  const lumbarStep = outLumbar - f1.lumbarComp;
  const maxLumbarStep = 9.0 * dtScale * energyMult;
  if (Math.abs(lumbarStep) > maxLumbarStep * 0.78) {
    outLumbar = f1.lumbarComp + softCapSigned(lumbarStep, maxLumbarStep);
  }
  const shear = outPose.waist + outLumbar - outPose.torso;
  if (Math.abs(shear) > 42 * energyMult) {
    const shearExcess = Math.abs(shear) - 42 * energyMult;
    limitTension = Math.max(limitTension, clampVal(shearExcess / 24, 0, 1));
    peakShock = Math.max(peakShock, Math.abs(shear) / (50 * energyMult));
    // Unspool: bleed torsion smoothly through thorax & collar rather than clamping lumbar hard
    const release = Math.sign(shear) * Math.min(shearExcess * 0.35, 14);
    outLumbar -= release * 0.45;
    outPose.torso += release * 0.35;
    outPose.collar -= release * 0.2;
  }

  // BREAK-NOTE [ROOT-IMPACT-SPIKE]: Cushion root jumps softly and transfer overflow to fall/unspool envelope.
  const dy = outPose.y_offset - f1.pose.y_offset;
  const dx = outPose.x_offset - f1.pose.x_offset;
  const rootStepY = 20 * dtScale * energyMult; // a sit->leap legitimately peaks ~17px/frame
  const rootStepX = 24 * dtScale * energyMult;
  if (Math.abs(dy) > rootStepY) {
    peakShock = Math.max(peakShock, Math.abs(dy) / rootStepY);
    outPose.y_offset = f1.pose.y_offset + softCapSigned(dy, rootStepY);
  }
  if (Math.abs(dx) > rootStepX) {
    outPose.x_offset = f1.pose.x_offset + softCapSigned(dx, rootStepX);
  }

  // SHITE-HAPPENS UNSPOOL ENVELOPE: Dissolves persistent limit-wall or shear tension into soft distal slack
  const targetUnspool = clampVal(limitTension * 0.85 + Math.max(0, peakShock - 1.0) * 0.35, 0, 1);
  const unspoolAlpha = targetUnspool > buf.unspoolEnergy ? 1 - Math.exp(-7 * dt) : 1 - Math.exp(-3.4 * dt);
  buf.unspoolEnergy = lerpVal(buf.unspoolEnergy, targetUnspool, unspoolAlpha);
  const slackSign = dominantTensionDir >= 0 ? 1 : -1;
  buf.unspoolSlack = lerpVal(buf.unspoolSlack, buf.unspoolEnergy * slackSign * 6.5, 1 - Math.exp(-5.5 * dt));

  // BREAK-NOTE [FALL-AND-RECOVER]: Only absorb genuinely severe balance shocks (never trigger on normal heel impacts).
  if (peakShock > 2.15) {
    const addedFall = clampVal((peakShock - 2.15) * 0.32, 0.04, 0.35);
    buf.fallDepth = Math.min(1, buf.fallDepth + addedFall);
    buf.fallHoldTimer = 0.1;
    buf.fallLeanSign = Math.abs(dx) > 0.5 ? (dx >= 0 ? 1 : -1) : outPose.waist >= 0 ? 1 : -1;
  } else if (buf.fallHoldTimer > 0) {
    buf.fallHoldTimer = Math.max(0, buf.fallHoldTimer - dt);
  } else if (buf.fallDepth > 0.001) {
    const riseRate = 1.9 * (1.15 - buf.fallDepth * 0.45);
    buf.fallDepth = Math.max(0, buf.fallDepth - riseRate * dt);
  }

  const isSagittal = bodyView === 'sideR' || bodyView === 'sideL';

  // Record un-bowed stabilized trajectory in f1/f2 so fall/unspool overlays never self-trigger shock
  buf.f2 = f1;
  buf.f1 = {
    pose: { ...outPose },
    lumbarComp: outLumbar,
    footGapX: buf.smoothedFootGapX,
  };

  // Apply gentle distal unspool release so locked joints relax smoothly instead of stopping & shaking
  if (buf.unspoolEnergy > 0.02) {
    const u = buf.unspoolEnergy * buf.unspoolEnergy * (3 - 2 * buf.unspoolEnergy);
    outPose.y_offset += u * 6.5;
    outPose.l_elbow += buf.unspoolSlack * 0.72;
    outPose.r_elbow -= buf.unspoolSlack * 0.72;
    outPose.l_hand += buf.unspoolSlack * 0.5;
    outPose.r_hand -= buf.unspoolSlack * 0.5;
    outPose.collar -= u * outPose.torso * 0.14;
    outPose.neck -= u * outPose.torso * 0.1;
  }

  if (buf.fallDepth > 0.001) {
    const w = buf.fallDepth * buf.fallDepth * (3 - 2 * buf.fallDepth);
    const dir = bodyView === 'sideL' ? -1 : bodyView === 'sideR' ? 1 : buf.fallLeanSign;
    outPose.y_offset += w * 32;
    outPose.torso += w * (isSagittal ? 14 * dir : 8);
    outPose.collar -= w * (isSagittal ? 7 * dir : 4);
    outPose.neck -= w * (isSagittal ? 4.5 * dir : 3);
    outPose.l_knee += w * (isSagittal ? 16 * dir : 10);
    outPose.r_knee += w * (isSagittal ? 16 * dir : -10);
    outPose.l_shoulder -= w * 8;
    outPose.r_shoulder += w * 8;
  }

  return { pose: outPose, lumbarComp: outLumbar };
}

// ============================================================================
// LOCAL BIOMECHANICAL IN-BETWEENING SYSTEM & MEMORYLESS (A -> B) SCREENSAVER
// 100% deterministic local kinematics (no APIs/LLMs). Matches physics of transitions
// across Walks <-> Idles, Stances <-> Seats, and Extreme <-> Lethargic states.
// ============================================================================

export type KinematicRegime = 'walk' | 'standing' | 'seated' | 'crouch' | 'airborne' | 'dynamic';

export interface KinematicEndpoint {
  pose: WalkingEnginePose;
  lumbarTwist: number;
  regime: KinematicRegime;
  energy: number; // ~0.15 (lethargic/sad) to 1.45 (sprint/extreme/airborne)
  bodyView: BodyViewMode;
  handPresetL: GotzHandPresetName;
  handPresetR: GotzHandPresetName;
  ribAnchor: RibAnchorMode;
  prometheusWings: boolean;
  isGrounded: boolean;
  nodeFlipX: Record<string, boolean>;
}

export function classifyProcessRegime(stanceId: string, moodId: ProcessMoodId, intensityId: ProcessIntensityId): {
  regime: KinematicRegime;
  energy: number;
} {
  const stance = STARTER_STANCE_CATALOG.find((s) => s.id === stanceId);
  const intenScale = INTENSITY_SCALES[intensityId] ?? 1.0;
  let regime: KinematicRegime = 'standing';
  if (stanceId === 'seatedPerched') regime = 'seated';
  else if (stanceId === 'kneelingPoise' || stanceId === 'deepCoil') regime = 'crouch';
  else if (stance?.airborne) regime = 'airborne';
  else if (stanceId === 'sprintDrive' || stanceId === 'lungeReach' || stanceId === 'walkStride') regime = 'dynamic';

  let moodEnergy = 0.55;
  if (moodId === 'melancholic') moodEnergy = 0.22;
  else if (moodId === 'composed' || moodId === 'guarded') moodEnergy = 0.42;
  else if (moodId === 'inquisitive') moodEnergy = 0.58;
  else if (moodId === 'heroic') moodEnergy = 0.78;
  else if (moodId === 'exuberant' || moodId === 'predatory' || moodId === 'dramatic') moodEnergy = 0.96;

  if (stance?.airborne || stanceId === 'sprintDrive') moodEnergy = Math.max(moodEnergy, 1.05);
  else if (stanceId === 'seatedPerched' || stanceId === 'deepCoil') moodEnergy *= 0.82;

  return {
    regime,
    energy: clampVal(moodEnergy * (0.65 + 0.35 * intenScale), 0.14, 1.5),
  };
}

export function buildProcessEndpoint(
  stanceId: string,
  moodId: ProcessMoodId,
  intensityId: ProcessIntensityId,
  bodyView: BodyViewMode,
  sideArmsFavorOpposite: boolean,
  breathPhase: number
): KinematicEndpoint {
  const out = computeProcessPose({
    stanceId,
    moodId,
    intensityId,
    bodyView,
    sideArmsFavorOpposite,
    breathPhase,
  });
  const cls = classifyProcessRegime(stanceId, moodId, intensityId);
  return {
    pose: out.pose,
    lumbarTwist: out.lumbarTwist,
    regime: cls.regime,
    energy: cls.energy,
    bodyView,
    handPresetL: out.handPresetL,
    handPresetR: out.handPresetR,
    ribAnchor: out.ribAnchor,
    prometheusWings: out.prometheusWings,
    isGrounded: out.isGrounded,
    nodeFlipX: out.nodeFlipX,
  };
}

function easeSmooth01(x: number): number {
  const t = clampVal(x, 0, 1);
  return t * t * (3 - 2 * t);
}

function easeHeavyDecel(x: number): number {
  const t = clampVal(x, 0, 1);
  return 1 - Math.pow(1 - t, 1.9);
}

function easePowerRise(x: number): number {
  const t = clampVal(x, 0, 1);
  // Symmetric ease-in-out of power n=2.4. The ease-in half MUST use 2^(n-1) * t^n to meet the ease-out half at (0.5, 0.5);
  // the old `2.4 * t^3` arrived at 0.30 and jumped to 0.50, a one-frame pop of 20% of the whole joint delta.
  return t < 0.5 ? Math.pow(2, 1.4) * Math.pow(t, 2.4) : 1 - Math.pow(-2 * t + 2, 2.4) / 2;
}

/** Heavy gravity settle that still leaves A at zero velocity (decel curve faded in over the first 30%). */
function easeSoftHeavyDecel(x: number, weight: number): number {
  const t = clampVal(x, 0, 1);
  const gate = easeSmooth01(t / 0.3);
  return lerpVal(easeSmooth01(t), easeHeavyDecel(t), weight * gate);
}

/** sin² bell: value AND slope are zero at both endpoints, so compensation arcs never kick A or B. */
const bell01 = (t: number): number => {
  const s = Math.sin(Math.PI * clampVal(t, 0, 1));
  return s * s;
};
const windowBell01 = (t: number, window: number): number => (t >= window ? 0 : bell01(t / window));

/**
 * Lead/lag time remap that keeps BOTH endpoints exact.
 * offset > 0 → group leads (finishes early and rests on B); offset < 0 → group lags (starts late, still lands at 1).
 * (The previous `clamp(t + offset)` form never reached B for lagging joints and began moving at t=0 for leading ones.)
 */
const staggerTime = (t: number, offset: number): number => {
  const o = clampVal(offset, -0.3, 0.3);
  return o >= 0 ? clampVal(t / (1 - o), 0, 1) : clampVal((t + o) / (1 + o), 0, 1);
};

export interface InBetweenResult {
  pose: WalkingEnginePose;
  lumbarTwist: number;
  feelIdUsed: MotionFeelId;
}

/**
 * Local biomechanical A -> B transition solver.
 * Shapes timing curves, core->proximal->distal wave stagger, seat-rise forward CoM pitch,
 * walk->idle deceleration settle, and swing-foot ground clearance from the kinematic delta of A and B.
 *
 * Friction contract (verified by tools/friction-probe.ts):
 *   - solve(A, B, 0) === A and solve(A, B, 1) === B for every joint (no pop at either handoff)
 *   - every compensation arc has zero value + zero slope at both ends
 */
export function solveKinematicInBetween(
  fromA: KinematicEndpoint,
  toB: KinematicEndpoint,
  rawT: number,
  userFeel: MotionFeelId = 'flow'
): InBetweenResult {
  const t = clampVal(rawT, 0, 1);
  const a = fromA.pose;
  const b = toB.pose;

  const isWalkToIdle = fromA.regime === 'walk' && toB.regime !== 'walk';
  const isIdleToWalk = fromA.regime !== 'walk' && toB.regime === 'walk';
  const aLow = fromA.regime === 'seated' || fromA.regime === 'crouch';
  const bLow = toB.regime === 'seated' || toB.regime === 'crouch';
  const dy = b.y_offset - a.y_offset;
  const isLowering = (!aLow && bLow) || dy > 85;
  const isRising = (aLow && !bLow) || dy < -85;

  const energyDelta = toB.energy - fromA.energy;
  const isWindingDown = energyDelta < -0.22;
  const isExploding = energyDelta > 0.28 || toB.regime === 'airborne';
  const lethargyFactor = clampVal(1 - toB.energy * 0.72, 0, 0.85);

  // Pick biomechanically appropriate motion feel & base warp
  let feelIdUsed: MotionFeelId = userFeel;
  if (isWindingDown || isLowering) feelIdUsed = 'flow';
  else if (isExploding) feelIdUsed = 'snap';

  // Base progress curve as a pure function of local time s (0 -> 0, 1 -> 1 for every branch).
  const baseCurve = (s: number): number => {
    if (isWindingDown) return easeSoftHeavyDecel(s, 0.65) * 0.5 + evaluateMotionCurve(s, feelIdUsed) * 0.5;
    if (isExploding) return easePowerRise(s);
    if (isLowering) return lerpVal(easeSmooth01(s), easeHeavyDecel(s), 0.35 * easeSmooth01(s / 0.3));
    if (isRising) return easePowerRise(s);
    if (isWalkToIdle) return easeSoftHeavyDecel(s, 1);
    if (isIdleToWalk) return easeSmooth01(clampVal((s - 0.06) / 0.94, 0, 1));
    return evaluateMotionCurve(s, feelIdUsed);
  };

  // Joint curve: blend the regime curve with a smoothstep so every group has a clean ease at both ends.
  const jointCurve = (s: number): number => {
    if (isWindingDown) return lerpVal(evaluateMotionCurve(s, feelIdUsed), easeSoftHeavyDecel(s, 0.65), 0.65);
    if (isRising || isExploding) return easePowerRise(s);
    return lerpVal(baseCurve(s), easeSmooth01(s), 0.5);
  };

  const baseProgress = baseCurve(t);

  // Hierarchical Core -> Proximal -> Distal phase stagger (both endpoints exact)
  const stagger = (leadOffset: number): number => {
    const scaled = leadOffset * (0.65 + lethargyFactor * 0.65);
    return jointCurve(staggerTime(t, scaled));
  };

  const tRoot = stagger(isRising ? 0.07 : 0.04);
  const tSpine = stagger(isWindingDown ? -0.02 : 0.02);
  const tHead = stagger(isWindingDown ? -0.11 : -0.05);
  const tShoulder = stagger(-0.03);
  const tElbow = stagger(-0.08);
  const tWrist = stagger(-0.13);
  const tHip = stagger(isLowering ? 0.04 : 0.02);
  const tKnee = stagger(isLowering ? 0.06 : -0.04);
  const tAnkle = stagger(isWalkToIdle ? -0.07 : -0.05);

  // Soft overshoot allowance only (elastic/snap bounce); exact at 0 and 1 because curves are exact there.
  const mix = (va: number, vb: number, u: number) => va + (vb - va) * clampVal(u, -0.08, 1.08);
  const arcBell = bell01(t);

  // Biomechanical compensation arcs during transition (all zero value + zero slope at both ends):
  // 1) Seat/Crouch <-> Standing: torso leans forward mid-arc ("nose-over-toes") to balance CoM over feet
  let pitchCoMComp = 0;
  let kneePushDipY = 0;
  if (isRising) {
    pitchCoMComp = arcBell * (fromA.bodyView === 'sideL' ? -14 : 14);
    kneePushDipY = windowBell01(t, 0.35) * 14;
  } else if (isLowering) {
    pitchCoMComp = arcBell * (toB.bodyView === 'sideL' ? -11 : 11);
  } else if (isExploding) {
    // Windup crouch before launch
    kneePushDipY = windowBell01(t, 0.22) * 18;
    pitchCoMComp = -windowBell01(t, 0.22) * 8;
  } else if (isWalkToIdle) {
    // Subtle deceleration settle knee cushion
    kneePushDipY = bell01(easeSmooth01(t)) * 10;
  }

  // 2) Swing-foot clearance lift so switching stances or walk->idle clears ground instead of scraping.
  // Gain is a continuous ramp of leg travel (was a hard >14° switch that popped the lift on/off between similar pairs).
  const lLegDelta = Math.abs(b.l_hip - a.l_hip) + Math.abs(b.l_knee - a.l_knee) * 0.45;
  const rLegDelta = Math.abs(b.r_hip - a.r_hip) + Math.abs(b.r_knee - a.r_knee) * 0.45;
  const isSagittal = toB.bodyView === 'sideR' || toB.bodyView === 'sideL';
  const clearGain = (delta: number): number => easeSmooth01((delta - 8) / 12);
  const noLiftRegime = isLowering || isRising ? 0 : 1;

  const lLiftClear = noLiftRegime * clearGain(lLegDelta) * arcBell * Math.min(22, lLegDelta * 0.32);
  const rLiftClear = noLiftRegime * clearGain(rLegDelta) * arcBell * Math.min(22, rLegDelta * 0.32);

  // Weight-shift lateral hip slide toward the more stationary leg (continuous in leg-delta imbalance)
  const shiftBias = clampVal((lLegDelta - rLegDelta) / 16, -1, 1);
  const weightShiftX = isSagittal ? 0 : arcBell * -10 * shiftBias;

  // 3) Distal arm follow-through drag in extreme <-> lethargic / walk <-> idle
  const armDeltaL = b.l_shoulder - a.l_shoulder;
  const armDeltaR = b.r_shoulder - a.r_shoulder;
  const dragGain = (isWindingDown ? 0.24 : 0.14) * arcBell;
  const DRAG_CAP = 16;
  const dragOf = (armDelta: number): number => DRAG_CAP * Math.tanh((armDelta * dragGain) / DRAG_CAP);

  const waist = mix(a.waist, b.waist, tRoot);
  const torso = mix(a.torso, b.torso, tSpine) + pitchCoMComp;
  const collar = mix(a.collar, b.collar, tHead) - pitchCoMComp * 0.55;
  const neck = mix(a.neck, b.neck, tHead) - pitchCoMComp * 0.32;

  const l_knee = mix(a.l_knee, b.l_knee, tKnee) + lLiftClear;
  const r_knee = mix(a.r_knee, b.r_knee, tKnee) - rLiftClear;

  return {
    pose: {
      waist,
      torso,
      collar,
      neck,
      l_shoulder: mix(a.l_shoulder, b.l_shoulder, tShoulder),
      r_shoulder: mix(a.r_shoulder, b.r_shoulder, tShoulder),
      l_elbow: mix(a.l_elbow, b.l_elbow, tElbow) - dragOf(armDeltaL),
      r_elbow: mix(a.r_elbow, b.r_elbow, tElbow) - dragOf(armDeltaR),
      l_hand: mix(a.l_hand, b.l_hand, tWrist) - dragOf(armDeltaL) * 0.7,
      r_hand: mix(a.r_hand, b.r_hand, tWrist) - dragOf(armDeltaR) * 0.7,
      l_hip: mix(a.l_hip, b.l_hip, tHip) - lLiftClear * 0.45,
      r_hip: mix(a.r_hip, b.r_hip, tHip) + rLiftClear * 0.45,
      l_knee,
      r_knee,
      l_foot: mix(a.l_foot, b.l_foot, tAnkle) - lLiftClear * 0.45,
      r_foot: mix(a.r_foot, b.r_foot, tAnkle) + rLiftClear * 0.45,
      l_toe: mix(a.l_toe, b.l_toe, tAnkle) + lLiftClear * 0.25,
      r_toe: mix(a.r_toe, b.r_toe, tAnkle) - rLiftClear * 0.25,
      stride_phase: mix(a.stride_phase, b.stride_phase, baseProgress),
      x_offset: mix(a.x_offset, b.x_offset, tRoot) + weightShiftX,
      y_offset: mix(a.y_offset, b.y_offset, tRoot) + kneePushDipY,
    },
    lumbarTwist: mix(fromA.lumbarTwist, toB.lumbarTwist, tSpine),
    feelIdUsed,
  };
}

export type ScreensaverChapterKind = 'process' | 'walk';

export interface ScreensaverChapterSpec {
  kind: ScreensaverChapterKind;
  stanceId: string;
  moodId: ProcessMoodId;
  intensityId: ProcessIntensityId;
  walkPresetIndex: number; // 0..5 for 'walk' chapters
  bodyView: BodyViewMode;
  sideArmsFavorOpposite: boolean;
  holdDuration: number;
  transitionDuration: number;
}

export interface ScreensaverDirectorState {
  phase: 'holding' | 'transitioning';
  elapsedInPhase: number;
  pointA: ScreensaverChapterSpec;
  pointB: ScreensaverChapterSpec;
  frozenEndpointA: KinematicEndpoint | null;
}

const SCREENSAVER_STANCE_WEIGHTS: Record<string, { nextStances: string[]; moods: ProcessMoodId[]; walkChance: number }> = {
  vitruvian: { nextStances: ['contrapposto', 'wideReady', 'seatedPerched', 'dorsalLookback'], moods: ['composed', 'heroic', 'inquisitive'], walkChance: 0.45 },
  contrapposto: { nextStances: ['vitruvian', 'dynamicTwist', 'archProfile', 'reposeProfile', 'dorsalLookback'], moods: ['composed', 'inquisitive', 'melancholic', 'heroic'], walkChance: 0.5 },
  wideReady: { nextStances: ['lungeReach', 'deepCoil', 'sentinelBack', 'contrapposto'], moods: ['heroic', 'predatory', 'dramatic'], walkChance: 0.4 },
  walkStride: { nextStances: ['contrapposto', 'lungeReach', 'archProfile', 'wideReady'], moods: ['composed', 'heroic', 'exuberant'], walkChance: 0.35 },
  sprintDrive: { nextStances: ['airborne', 'stalkProfile', 'deepCoil', 'contrapposto'], moods: ['predatory', 'dramatic', 'heroic'], walkChance: 0.2 },
  lungeReach: { nextStances: ['contrapposto', 'archProfile', 'dynamicTwist', 'vitruvian'], moods: ['heroic', 'guarded', 'dramatic'], walkChance: 0.35 },
  airborne: { nextStances: ['deepCoil', 'kneelingPoise', 'wideReady', 'contrapposto'], moods: ['exuberant', 'dramatic', 'melancholic'], walkChance: 0.2 },
  seatedPerched: { nextStances: ['vitruvian', 'reposeProfile', 'sphinxPerch', 'deepCoil'], moods: ['melancholic', 'inquisitive', 'composed'], walkChance: 0.35 },
  kneelingPoise: { nextStances: ['sphinxPerch', 'lungeReach', 'contrapposto', 'vitruvian'], moods: ['guarded', 'heroic', 'melancholic'], walkChance: 0.3 },
  deepCoil: { nextStances: ['stalkProfile', 'wideReady', 'seatedPerched', 'contrapposto'], moods: ['guarded', 'melancholic', 'predatory'], walkChance: 0.3 },
  dynamicTwist: { nextStances: ['contrapposto', 'dorsalLookback', 'promethean', 'lungeReach'], moods: ['dramatic', 'inquisitive', 'exuberant'], walkChance: 0.4 },
  promethean: { nextStances: ['sentinelBack', 'contrapposto', 'dynamicTwist', 'seatedPerched'], moods: ['heroic', 'dramatic', 'composed'], walkChance: 0.4 },
  archProfile: { nextStances: ['reposeProfile', 'stalkProfile', 'lungeReach', 'dorsalLookback'], moods: ['heroic', 'composed', 'inquisitive'], walkChance: 0.4 },
  reposeProfile: { nextStances: ['archProfile', 'sphinxPerch', 'contrapposto', 'dorsalLookback'], moods: ['composed', 'melancholic', 'inquisitive'], walkChance: 0.35 },
  stalkProfile: { nextStances: ['lungeReach', 'deepCoil', 'archProfile', 'sentinelBack'], moods: ['predatory', 'guarded', 'dramatic'], walkChance: 0.35 },
  sphinxPerch: { nextStances: ['seatedPerched', 'reposeProfile', 'kneelingPoise', 'contrapposto'], moods: ['inquisitive', 'melancholic', 'composed'], walkChance: 0.3 },
  dorsalLookback: { nextStances: ['sentinelBack', 'contrapposto', 'reposeProfile', 'dynamicTwist'], moods: ['inquisitive', 'composed', 'guarded'], walkChance: 0.4 },
  sentinelBack: { nextStances: ['dorsalLookback', 'wideReady', 'promethean', 'archProfile'], moods: ['heroic', 'guarded', 'dramatic'], walkChance: 0.4 },
};

const ALL_BODY_VIEWS: readonly BodyViewMode[] = [
  'front',
  'threeQuarterR',
  'sideR',
  'threeQuarterL',
  'sideL',
  'back',
];

function pickMarkovAdjacentView(current: BodyViewMode): BodyViewMode {
  const idx = ALL_BODY_VIEWS.indexOf(current);
  if (idx < 0 || Math.random() < 0.25) {
    return ALL_BODY_VIEWS[Math.floor(Math.random() * ALL_BODY_VIEWS.length)];
  }
  const step = Math.random() < 0.5 ? 1 : -1;
  const nextIdx = (idx + step + ALL_BODY_VIEWS.length) % ALL_BODY_VIEWS.length;
  return ALL_BODY_VIEWS[nextIdx];
}

function pickRandom<T>(arr: readonly T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

/**
 * Picks ONLY Point B given Point A (Markov-1, zero past history beyond current state A).
 */
export function pickNextScreensaverTarget(fromA: ScreensaverChapterSpec): ScreensaverChapterSpec {
  const table = SCREENSAVER_STANCE_WEIGHTS[fromA.stanceId] ?? SCREENSAVER_STANCE_WEIGHTS.contrapposto;
  const nextBodyView = pickMarkovAdjacentView(fromA.bodyView);
  const sideArmsFavorOpposite = Math.random() < 0.35;

  // Walk chapters alternate organically with Pose/Stance/Seat chapters
  const chooseWalk = fromA.kind === 'walk' ? Math.random() < 0.22 : Math.random() < table.walkChance;

  if (chooseWalk) {
    // Calibrated walk presets (2 = Natural Walk, 0 = Tip-Toe, 1 = Shuffle, 4 = Skate, 5 = Inkwell, 3 = Run)
    const walkChoices = [2, 2, 0, 1, 4, 5, 3];
    const walkPresetIndex = pickRandom(walkChoices);
    const transitionDuration = walkPresetIndex === 1 ? 1.25 : walkPresetIndex === 3 ? 0.72 : 0.95;
    const holdDuration = walkPresetIndex === 3 ? 1.8 : 2.5 + Math.random() * 1.1;
    return {
      kind: 'walk',
      stanceId: 'walkStride',
      moodId: walkPresetIndex === 1 ? 'melancholic' : walkPresetIndex === 5 ? 'exuberant' : 'composed',
      intensityId: walkPresetIndex === 3 || walkPresetIndex === 5 ? 'dramatic' : 'standard',
      walkPresetIndex,
      bodyView: nextBodyView,
      sideArmsFavorOpposite,
      holdDuration,
      transitionDuration,
    };
  }

  const nextStanceId = pickRandom(table.nextStances);
  const nextMoodId = pickRandom(table.moods);
  const intensityPool: ProcessIntensityId[] =
    nextMoodId === 'melancholic'
      ? ['subtle', 'standard']
      : nextMoodId === 'dramatic' || nextStanceId === 'airborne'
        ? ['standard', 'dramatic']
        : ['subtle', 'standard', 'dramatic'];
  const nextIntensity = pickRandom(intensityPool);

  // Match transition pacing to biomechanical distance & energy shift
  const clsA = classifyProcessRegime(fromA.stanceId, fromA.moodId, fromA.intensityId);
  const clsB = classifyProcessRegime(nextStanceId, nextMoodId, nextIntensity);
  const isSlowShift =
    nextMoodId === 'melancholic' ||
    nextStanceId === 'seatedPerched' ||
    nextStanceId === 'deepCoil' ||
    (fromA.kind === 'walk' && clsB.energy < 0.55);
  const isFastShift = clsB.regime === 'airborne' || clsB.energy - clsA.energy > 0.3;

  const transitionDuration = isFastShift
    ? 0.72 + Math.random() * 0.25
    : isSlowShift
      ? 1.35 + Math.random() * 0.45
      : 0.95 + Math.random() * 0.35;

  const holdDuration =
    nextStanceId === 'airborne'
      ? 0.75
      : 1.55 + Math.random() * 1.25;

  return {
    kind: 'process',
    stanceId: nextStanceId,
    moodId: nextMoodId,
    intensityId: nextIntensity,
    walkPresetIndex: 2,
    bodyView: nextBodyView,
    sideArmsFavorOpposite,
    holdDuration,
    transitionDuration,
  };
}

export function createScreensaverDirector(
  initialBodyView: BodyViewMode = 'front',
  initialStanceId = 'contrapposto',
  initialMoodId: ProcessMoodId = 'composed'
): ScreensaverDirectorState {
  const pointA: ScreensaverChapterSpec = {
    kind: 'process',
    stanceId: initialStanceId,
    moodId: initialMoodId,
    intensityId: 'standard',
    walkPresetIndex: 2,
    bodyView: initialBodyView,
    sideArmsFavorOpposite: false,
    holdDuration: 1.4,
    transitionDuration: 1.0,
  };
  return {
    phase: 'holding',
    elapsedInPhase: 0,
    pointA,
    pointB: pickNextScreensaverTarget(pointA),
    frozenEndpointA: null,
  };
}

/**
 * Guided Cutout Walk Engine (Local Deterministic Non-Mechanized Variator)
 * Guides an articulated cardboard cutout step-by-step with very slight organic variables
 * (cadence breathing, slight L/R stride & arm asymmetry, gaze & posture drift, and
 * incommensurate harmonic timing offsets) so walking feels hand-guided rather than baked.
 */
export interface GuidedCutoutWalkSample {
  cadenceMul: number;
  strideMulL: number;
  strideMulR: number;
  phaseOffsetL: number;
  phaseOffsetR: number;
  armMulL: number;
  armMulR: number;
  elbowOffsetL: number;
  elbowOffsetR: number;
  wristOffsetL: number;
  wristOffsetR: number;
  kneeCushionL: number;
  kneeCushionR: number;
  footPitchL: number;
  footPitchR: number;
  chestDrift: number;
  lumbarDrift: number;
  headGlance: number;
  swayOffsetX: number;
}

export interface GuidedCutoutWalkState {
  lastStepIdx: number;
  lastPhraseIdx: number;
  target: GuidedCutoutWalkSample;
  current: GuidedCutoutWalkSample;
}

const NEUTRAL_GUIDED_CUTOUT: GuidedCutoutWalkSample = {
  cadenceMul: 1,
  strideMulL: 1,
  strideMulR: 1,
  phaseOffsetL: 0,
  phaseOffsetR: 0,
  armMulL: 1,
  armMulR: 1,
  elbowOffsetL: 0,
  elbowOffsetR: 0,
  wristOffsetL: 0,
  wristOffsetR: 0,
  kneeCushionL: 0,
  kneeCushionR: 0,
  footPitchL: 0,
  footPitchR: 0,
  chestDrift: 0,
  lumbarDrift: 0,
  headGlance: 0,
  swayOffsetX: 0,
};

export function createGuidedCutoutWalkState(): GuidedCutoutWalkState {
  return {
    lastStepIdx: -1,
    lastPhraseIdx: -1,
    target: { ...NEUTRAL_GUIDED_CUTOUT },
    current: { ...NEUTRAL_GUIDED_CUTOUT },
  };
}

const randSym = (amp: number): number => (Math.random() * 2 - 1) * amp;

export function stepGuidedCutoutWalk(
  state: GuidedCutoutWalkState,
  totalPhase: number,
  dt: number,
  enabled: boolean
): GuidedCutoutWalkSample {
  if (!enabled) {
    state.target = { ...NEUTRAL_GUIDED_CUTOUT };
    const settleAlpha = 1 - Math.exp(-8.5 * dt);
    (Object.keys(NEUTRAL_GUIDED_CUTOUT) as Array<keyof GuidedCutoutWalkSample>).forEach((k) => {
      state.current[k] = lerpVal(state.current[k], NEUTRAL_GUIDED_CUTOUT[k], settleAlpha);
    });
    return state.current;
  }

  // Per-step puppeteer micro-intent (every half-cycle pi) — gentle non-shaking organic drift
  const stepIdx = Math.floor(totalPhase / Math.PI);
  if (stepIdx !== state.lastStepIdx) {
    state.lastStepIdx = stepIdx;
    const isLeftStep = stepIdx % 2 === 0;

    state.target.cadenceMul = 1 + randSym(0.032);
    state.target.strideMulL = isLeftStep ? 1 + randSym(0.045) : lerpVal(state.target.strideMulL, 1, 0.45);
    state.target.strideMulR = !isLeftStep ? 1 + randSym(0.045) : lerpVal(state.target.strideMulR, 1, 0.45);
    state.target.armMulL = 1 + randSym(0.055);
    state.target.armMulR = 1 + randSym(0.055);
    state.target.elbowOffsetL = randSym(2.1);
    state.target.elbowOffsetR = randSym(2.1);
    state.target.wristOffsetL = randSym(2.4);
    state.target.wristOffsetR = randSym(2.4);
    state.target.kneeCushionL = isLeftStep ? randSym(1.6) : lerpVal(state.target.kneeCushionL, 0, 0.45);
    state.target.kneeCushionR = !isLeftStep ? randSym(1.6) : lerpVal(state.target.kneeCushionR, 0, 0.45);
    state.target.footPitchL = isLeftStep ? randSym(1.4) : state.target.footPitchL * 0.65;
    state.target.footPitchR = !isLeftStep ? randSym(1.4) : state.target.footPitchR * 0.65;
  }

  // Slower 2-stride phrase guidance (carriage, head curiosity, balance lean)
  const phraseIdx = Math.floor(totalPhase / (Math.PI * 3));
  if (phraseIdx !== state.lastPhraseIdx) {
    state.lastPhraseIdx = phraseIdx;
    state.target.chestDrift = randSym(1.8);
    state.target.lumbarDrift = randSym(1.4);
    state.target.headGlance = randSym(2.6);
    state.target.swayOffsetX = randSym(2.5);
  }

  // Smooth exponential follow so cardboard cutout joints glide without jitter
  const fastAlpha = 1 - Math.exp(-3.2 * dt);
  const slowAlpha = 1 - Math.exp(-1.8 * dt);

  state.current.cadenceMul = lerpVal(state.current.cadenceMul, state.target.cadenceMul, fastAlpha);
  state.current.strideMulL = lerpVal(state.current.strideMulL, state.target.strideMulL, fastAlpha);
  state.current.strideMulR = lerpVal(state.current.strideMulR, state.target.strideMulR, fastAlpha);
  state.current.armMulL = lerpVal(state.current.armMulL, state.target.armMulL, fastAlpha);
  state.current.armMulR = lerpVal(state.current.armMulR, state.target.armMulR, fastAlpha);
  state.current.elbowOffsetL = lerpVal(state.current.elbowOffsetL, state.target.elbowOffsetL, fastAlpha);
  state.current.elbowOffsetR = lerpVal(state.current.elbowOffsetR, state.target.elbowOffsetR, fastAlpha);
  state.current.wristOffsetL = lerpVal(state.current.wristOffsetL, state.target.wristOffsetL, fastAlpha);
  state.current.wristOffsetR = lerpVal(state.current.wristOffsetR, state.target.wristOffsetR, fastAlpha);
  state.current.kneeCushionL = lerpVal(state.current.kneeCushionL, state.target.kneeCushionL, fastAlpha);
  state.current.kneeCushionR = lerpVal(state.current.kneeCushionR, state.target.kneeCushionR, fastAlpha);
  state.current.footPitchL = lerpVal(state.current.footPitchL, state.target.footPitchL, fastAlpha);
  state.current.footPitchR = lerpVal(state.current.footPitchR, state.target.footPitchR, fastAlpha);

  state.current.chestDrift = lerpVal(state.current.chestDrift, state.target.chestDrift, slowAlpha);
  state.current.lumbarDrift = lerpVal(state.current.lumbarDrift, state.target.lumbarDrift, slowAlpha);
  state.current.headGlance = lerpVal(state.current.headGlance, state.target.headGlance, slowAlpha);
  state.current.swayOffsetX = lerpVal(state.current.swayOffsetX, state.target.swayOffsetX, slowAlpha);

  // Gentle incommensurate harmonic undercurrent (low-frequency fluid drift)
  const h1 = Math.sin(totalPhase * 0.21 + 0.7);
  const h2 = Math.sin(totalPhase * 0.33 + 2.1);
  const h3 = Math.cos(totalPhase * 0.17 + 1.4);

  return {
    ...state.current,
    phaseOffsetL: h1 * 0.028 + h2 * 0.014,
    phaseOffsetR: -h1 * 0.024 + h3 * 0.016,
    wristOffsetL: state.current.wristOffsetL + h2 * 1.3,
    wristOffsetR: state.current.wristOffsetR - h3 * 1.3,
    chestDrift: state.current.chestDrift + h3 * 0.85,
    headGlance: state.current.headGlance + h1 * 1.0,
    swayOffsetX: state.current.swayOffsetX + h2 * 1.1,
  };
}


