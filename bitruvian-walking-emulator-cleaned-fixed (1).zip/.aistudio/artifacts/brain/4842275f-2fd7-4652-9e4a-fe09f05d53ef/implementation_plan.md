# Bitruvius Unified Emulator: Physics + Process Consolidation

Consolidates the procedural locomotion engine (`Bitruvius.Physics`) with the idle and pose-to-pose kinematic system (`Bitruvius.Process`), adding upper/lower spine pivot resistance, clean non-crossing foot kinematics without Newton's Cradle oscillation, true side and three-quarter body turns, and an incremental path toward the Spectrum Deck (Wheel, D-Pad, Searchable List, and Study Overlays).

---

## User Review & Critical Decisions

> [!IMPORTANT]
> **Incremental Execution Gate**: Per your workflow request, this consolidation is split into **three explicit increments**. Approving this plan (`Proceed`) executes **Increment 1** (Spine Resistance, Clean Non-Crossing Feet, True Side/3-4 Body Views, and Core Physics↔Process Mode Bridge). Once Increment 1 compiles and stabilizes, execution will pause with a short prompt telling you to enter Plan Mode for **Increment 2** (Spectrum Deck UI: Wheel, D-Pad, Searchable Fine Details, Notation, and Study Overlays).

- **Confirmed Decision 1 — Foot System Cleanup**: Remove the Newton's Cradle impulse/rebound wave and enforce lateral non-crossing foot lanes around midline so strides look natural without crossing or oscillating.
- **Confirmed Decision 2 — Spine Resistance & Counterbalance**: Port soft angular resistance (`_e` saturation) and pelvis-counter-rotation compensation (`Dt`) across the `lumbar ↔ thorax` pivot so default walking stays upright and self-balancing rather than tilty.
- **Confirmed Decision 3 — First Side & 3/4 Poses**: Port the six-angle body-turn geometry (`Front`, `3/4 R`, `Right Side`, `Back`, `Left Side`, `3/4 L`) including lateral pivot narrowing, profile limb angles, near/far piece depth sorting, and `Favor Opposite` arm toggle.
- **Recommended Default — Preserved Stage Palette & Typography**: Retain Bitruvius's high-contrast `Light` / `Dark` canvas palettes paired with royal purple (`#A855F7` / `#7C3AED`) and emerald green (`#22C55E` / `#059669`) functional accents alongside `JetBrains Mono` / `VT323` telemetry readouts inside the Spectrum Deck layout.

---

## 1. Overview & Core Concept

- **What It Does**: Unifies two complementary sides of the same articulated procedural puppet:
  1. **Locomotion Physics (`Walk` Mode)**: Real-time walking, tip-toeing, shuffling, sprinting, skating (`Skate Mode`), and Fleischer rubber-hose motion (`Cartoon Inkwell`), stabilized by damped spine resistance, compensatory counterbalancing, uneven ground hitches, and non-crossing feet.
  2. **Idle & Pose-to-Pose Study (`Process` Mode)**: Expressive anatomical posing built on the 12-stance catalog (`Vitruvian`, `Contrapposto`, `Wide Power`, `Walking Stride`, `Sprint Drive`, `Lunge Reach`, `Airborne Leap`, `Seated`, `Kneeling`, `Crouch`, `S-Twist`, `Promethean Chungus`), subtle breathing/weight-shift idles, six true body turns including first side views, A⇄B interpolation feels, pinned sequences (`P1–P5`), and writable pose notation.
- **Target Audience**: Character animators, riggers, figure-drawing students, and procedural motion designers testing weight distribution, silhouettes, and kinematics across front, three-quarter, side, and back perspectives.
- **Key Value**: One continuous rig where the Wheel, D-Pad, and Fine Details controls adapt fluidly whether the user is sculpting a static contrapposto silhouette from the side or tuning a forward walk cycle in 3rd-person back view.

---

## 2. User Experience & Visual Design

### Incremental Rollout Roadmap

1. **Increment 1 (Execute First upon Approval — Core Physics & Side Views)**:
   - Upgrade the `lumbar ↔ thorax` joint pivot with soft resistance saturation and compensatory pelvic counterbalance so `Natural Walk` holds a poised, grounded upright torso.
   - Remove the Newton's Cradle foot impulse/collision system; keep tightened anatomical forefoot rays with smooth 3-zone roll and add hard non-crossing lateral lane separation so feet never tangle or cross midline.
   - Add the `Body Turn` selector (`Front`, `3/4 R`, `Side R`, `Back`, `Side L`, `3/4 L` + `Favor Opposite`) using `Bitruvius.Process`'s lateral pivot compression, profile joint offsets, and near-side-over-far-side depth sorting.
   - Add a top-level `Engine Mode` (`Walk` vs. `Process / Pose`) with starter stances and `Motion Feel` interpolation so idle/pose-to-pose and side views run live on the existing stage right away.
2. **Increment 2 (Next Plan-Mode Cycle — Unified Spectrum Deck UI)**:
   - Restructure the workspace into a two-zone educational simulation sandbox: a dominant viewport stage (`60%–70%` vertical height) above a compact **Live Dock** (`Take 1–4`, `Surprise / Screensaver`, `Undo`, `A/B` slots, `Play`, `Figure / Bones / X-Ray`, `Study / Reference`, `Line / Balance / Hips-Shoulders / Guides / Ghosts`, `Pin P1–P5`) and a **3-Column Spectrum Deck** (`Wheel` · `D-Pad` · `Searchable Fine Details List`), plus collapsible `Notation`, `JSON`, `Sources`, and `Export` drawers.
3. **Increment 3 (Final Polish — Seamless Walk ↔ Idle ↔ Edit Flow)**:
   - Continuous transitions between `Walk` loops, settled idle `Process` stances, pinned keyframe reels, and canvas click-to-nudge `Edit` overrides saved to custom stances.

### Aesthetic Direction & Educational Simulation Hierarchy

- **Two-Zone Sandbox Balance**: Keeps the articulated figure unobscured in a high-clarity stage occupying most of the screen, with crisp hairline borders (`1px`) framing the compact Deck below.
- **60-30-10 Color Budget**:
  - **60% Dominant Stage**: Clean light green-tinted paper (`#F6FCF7`) or deep obsidian slate (`#0B0D12`) depending on theme toggle.
  - **30% Structural Panels & Grids**: Subtle border panels (`#D2E3D7` / `#272D3D`) and orthographic proportion guides.
  - **10% Dual-Coded Semantic Accents**: Royal purple (`#7C3AED` / `#A855F7`) for active selections, ring indicators, and near-side joint highlights; emerald green (`#059669` / `#22C55E`) for reset hubs, active switches, and balance axes; magenta-red (`#D81B60` / `#F04282`) strictly for anatomical Line of Action arcs and limit warnings—always paired with explicit labels and numeric units (`deg`, `%`, `fps`), never color alone.
- **Contextual Mapping Across Modes**:
  - **Wheel (`1 · Blend`)**: Adjusts `Mood / Gait Preset` + strength radius + outer 5-way Delsarte `Direction` ring (`Out`, `Up`, `In`, `Down`, `Even`), `Body Turn` (all 6 headings), `Skull 360°`, and `Motion Feel` (`Flow`, `Snap`, `Elastic`, `Mechanical`) with live SVG curve preview.
  - **D-Pad (`2 · Aim`)**: Contextualizes `Camera` (horizon elevation & vanishing point), `Spine` (lean bias / counter-tilt), `Head` (pitch / bobble / tilt), and `Edit` (`< Joint >`, `-2° / +2°` hold-nudge, Reset, Save Stance).
  - **Fine Details (`3 · Searchable List`)**: Instant search filtering across collapsible accordions with `‹ ›` steppers, labeled numeric sliders, and boolean switches covering gait tuning, foot/hand systems, body proportions, and export actions.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Removing Newton's Cradle in Favor of Lateral Lane Separation**:
  - *Chosen Approach*: Strip cross-digit collision bounce and cradle impulse waves from the 23-bone foot solver, retaining the clean 3-zone roll (`Heel → Arch → Tightened Toes`), and clamp horizontal foot offsets outside a minimum midline clearance corridor (`minLaneHalfGap`).
  - *Why*: Eliminates unnatural toe chatter and stride crossover while keeping ground contact crisp and believable from front, side, and back views.
  - *Alternatives Considered*: Dampening Newton's Cradle gains further; rejected because impulse bouncing on toes inherently introduces micro-oscillations during stance loading.
- **Decision 2 — Porting Damped Spine Saturation & Counter-Rotation (`_e` + `Dt`)**:
  - *Chosen Approach*: Route `lumbar` and `thorax` angles through soft `tanh`-style progressive resistance past anatomical comfort thresholds and subtract proportional pelvic counter-rotation (`lumbar` and `thorax` opposing excessive pelvis tilt, plus neck/head horizon leveling).
  - *Why*: Gives the spine spring-like resistance at the waist pivot instead of linear compounding lean, producing an immediate, poised default walk without dulling expressive stunts when pushed.
  - *Alternatives Considered*: Simply halving walk preset `lean` values; rejected because it flattens dynamic range in `Sprint`, `Skate`, and `Cartoon (Inkwell)` modes.
- **Decision 3 — Unified 6-Angle Body Turn Architecture**:
  - *Chosen Approach*: Apply `Bitruvius.Process`'s lateral pivot narrowing (`applyBodyViewPivots`), piece layer ordering (`sortPiecesForBodyView`), and asymmetric limb depth cues across both static poses and active walking strides.
  - *Why*: Delivers the rig's first true `Side` and `3/4` views cleanly on top of the existing vector/bitmap puppet without altering any underlying sprite asset files.

---

## 4. Technical Architecture & Data Strategy

### Consolidated System Flow

```text
┌───────────────────────────────────────────────────────────────────────────┐
│                         UNIFIED ENGINE CONTROLLER                         │
│   Engine Mode: [ Walk (Physics) ]  ⇄  [ Process (Idle & Pose-to-Pose) ]   │
└──────────────────────────────┬──────────────────────────┬─────────────────┘
                               │                          │
              ┌────────────────▼──────────┐  ┌────────────▼────────────────┐
              │    BITRUVIUS.PHYSICS      │  │     BITRUVIUS.PROCESS       │
              │  • Gait Cycle Integrator  │  │  • 12-Stance Catalog +      │
              │  • Spine Resistance (_e)  │  │    Mood/Delsarte Blender    │
              │  • Pelvic Counter-Bal(Dt) │  │  • Motion Feel Easing Curves│
              │  • Non-Crossing FootLane  │  │  • Pins (P1–P5) & A⇄B Morph │
              │  • 2nd-Order Knee/Elbow   │  │  • Notation CLI + READ Math │
              └────────────────┬──────────┘  └────────────┬────────────────┘
                               │                          │
                               └───────────┬──────────────┘
                                           ▼
                    ┌─────────────────────────────────────────────┐
                    │       SHARED CANONICAL PUPPYT RIG CORE      │
                    │  • 6-Angle Body Turn (Front, 3/4, Side, Bk) │
                    │  • Soft Shoulder/Spine Constraint Solver    │
                    │  • Near/Far Limb Z-Order Sorter             │
                    │  • Tight 23-Bone 3-Zone Piggy Foot + Hands  │
                    └──────────────────────┬──────────────────────┘
                                           ▼
        ┌──────────────────────────────────────────────────────────────────┐
        │   SPECTRUM DECK UI (Increment 2 Consolidation)                   │
        │   [Interactive Stage + LoA/CoG/Canon Overlays]                   │
        │   [Live Dock: Take · Surprise · A⇄B · Pin · Study/Ref]           │
        │   [1 · Wheel]     [2 · D-Pad / Edit]     [3 · Searchable List]   │
        └──────────────────────────────────────────────────────────────────┘
```

### Data Model & State Boundaries

- **Shared Rig Transform Contract**: Both engines output a normalized joint-angle map, root translation `(tx, ty)`, per-node `flipX` flags, active `bodyView` (`front | threeQuarterR | sideR | back | sideL | threeQuarterL`), `ribAnchor`, `prometheusWings`, hand states (`L`/`R`), and clean 3-zone foot states (`L`/`R`).
- **Spine Stability State**: Smoothed velocity/damping buffers track lumbar-thorax pivot shear and pelvis counter-rotation continuously so switching presets, speeds, or body turns stays glitch-free.
- **Foot Separation & Contact State**: Tracks each foot's world ankle X relative to `CENTER_X`, clamping hip adduction or glide drift so neither foot crosses the opposite lane during walking or side balance turns, while preserving toe-break pitch on push-off.
- **Process Recipe State (Persisted Client-Side via `localStorage`)**: Stores active procedural recipe (`mood`, `stance`, `bodyView`, `skullFacing`, `direction`, `intensity`, `elevation`, `vanishing`, `ribAnchor`, toggles), bounded 3-step `Undo` history for `A⇄B` playback, up to 5 stage `Pins`, and user-saved custom stances.

### Interactive Component & Handler Mapping (Increment 1 Scope First)

- **`Engine Mode` Switch (`Walk` / `Process`)**: Transitions smoothly via `easeInOut` interpolation into either continuous procedural gait or idle-breathing procedural stance evaluation.
- **`Body Turn` 6-Way Selector & `Favor Opposite` Toggle**: Recomputes lateral shoulder/hip pivots around `CENTER_X`, re-sorts piece depth indices (`near side > torso > far side`), updates foot/skull orientation rules, and stabilizes camera-relative lateral mirroring.
- **Spine Resistance & Foot Lane Safeguards**: Always active inside the shared solver; `Natural Walk` uses calibrated lower/upper spine resistance so the head and ribcage stay naturally poised over the stance foot while `Skate` and `Cartoon (Inkwell)` preserve their stylistic range within non-crossing lateral tracks.
- **Completion Checkpoint for Increment 1**: Build verification followed by a concise pause prompting the user to re-enter **Plan Mode** for **Increment 2** (full Spectrum Deck Wheel, D-Pad, Searchable Accordion List, Study Overlays, and Notation Drawer).
