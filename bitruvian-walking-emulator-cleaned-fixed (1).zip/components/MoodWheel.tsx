import React, { useRef, useState } from 'react';
import { ProcessIntensityId, ProcessMoodId } from '../types';
import { MOOD_SPECS } from '../utils/process-engine';

export type WheelSpectrumId =
  | 'mood'
  | 'stride'
  | 'frequency'
  | 'bounce'
  | 'lean'
  | 'arm_swing'
  | 'perspective';

export const WHEEL_SPECTRUM_ORDER: readonly { id: WheelSpectrumId; label: string }[] = [
  { id: 'mood', label: 'Mood' },
  { id: 'stride', label: 'Stride' },
  { id: 'frequency', label: 'Tempo' },
  { id: 'bounce', label: 'Bounce' },
  { id: 'lean', label: 'Lean' },
  { id: 'arm_swing', label: 'Arms' },
  { id: 'perspective', label: 'Depth' },
] as const;

export interface ClickWheelMenuItem {
  id: string;
  label: string;
  /** Right-aligned current value (e.g. "Walk", "On"). */
  valueText?: string;
  isActive?: boolean;
  /** Leaf action. Items with `children` drill in instead. */
  onSelect?: () => void;
  children?: ClickWheelMenuItem[];
}

interface MoodWheelProps {
  moodId: ProcessMoodId;
  intensityId: ProcessIntensityId;
  onSelect: (moodId: ProcessMoodId, intensityId: ProcessIntensityId) => void;
  spectrumId?: WheelSpectrumId;
  onChangeSpectrum?: (id: WheelSpectrumId) => void;
  spectrumValueNorm?: number;
  spectrumDisplayText?: string;
  onChangeSpectrumNorm?: (norm: number) => void;
  isPaused?: boolean;
  onTogglePause?: () => void;
  onPrevView?: () => void;
  onNextView?: () => void;
  activeViewLabel?: string;
  engineModeLabel?: string;
  onCycleMode?: () => void;
  menuTree?: ClickWheelMenuItem[];
  statusHeadline?: string;
}

const INTENSITY_RINGS: readonly { id: ProcessIntensityId; label: string; normR: number }[] = [
  { id: 'subtle', label: 'Subtle', normR: 0.44 },
  { id: 'standard', label: 'Std', normR: 0.64 },
  { id: 'dramatic', label: 'Dram', normR: 0.82 },
  { id: 'extreme', label: 'Ext', normR: 1.0 },
];

const INTENSITY_INDEX: Record<ProcessIntensityId, number> = {
  subtle: 0,
  standard: 1,
  dramatic: 2,
  extreme: 3,
};

function wedgePath(
  cx: number,
  cy: number,
  rIn: number,
  rOut: number,
  a0Deg: number,
  a1Deg: number
): string {
  const rad = Math.PI / 180;
  const a0 = a0Deg * rad;
  const a1 = a1Deg * rad;
  const x0 = cx + rOut * Math.cos(a0);
  const y0 = cy + rOut * Math.sin(a0);
  const x1 = cx + rOut * Math.cos(a1);
  const y1 = cy + rOut * Math.sin(a1);
  const x2 = cx + rIn * Math.cos(a1);
  const y2 = cy + rIn * Math.sin(a1);
  const x3 = cx + rIn * Math.cos(a0);
  const y3 = cy + rIn * Math.sin(a0);
  const large = a1Deg - a0Deg > 180 ? 1 : 0;
  return `M ${x0.toFixed(2)} ${y0.toFixed(2)} A ${rOut} ${rOut} 0 ${large} 1 ${x1.toFixed(2)} ${y1.toFixed(2)} L ${x2.toFixed(2)} ${y2.toFixed(2)} A ${rIn} ${rIn} 0 ${large} 0 ${x3.toFixed(2)} ${y3.toFixed(2)} Z`;
}

function arcPath(cx: number, cy: number, r: number, startDeg: number, endDeg: number): string {
  const clampedEnd = Math.max(startDeg + 0.5, endDeg);
  const rad = Math.PI / 180;
  const x0 = cx + r * Math.cos(startDeg * rad);
  const y0 = cy + r * Math.sin(startDeg * rad);
  const x1 = cx + r * Math.cos(clampedEnd * rad);
  const y1 = cy + r * Math.sin(clampedEnd * rad);
  const large = clampedEnd - startDeg > 180 ? 1 : 0;
  return `M ${x0.toFixed(2)} ${y0.toFixed(2)} A ${r} ${r} 0 ${large} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
}

export const MoodWheel: React.FC<MoodWheelProps> = ({
  moodId,
  intensityId,
  onSelect,
  spectrumId = 'mood',
  onChangeSpectrum,
  spectrumValueNorm = 0.5,
  spectrumDisplayText,
  onChangeSpectrumNorm,
  isPaused = false,
  onTogglePause,
  onPrevView,
  onNextView,
  activeViewLabel = 'Front',
  engineModeLabel = 'Walk',
  onCycleMode,
  menuTree,
  statusHeadline,
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  // Drill-down path of menu item ids. Resolved against the live tree each render so labels/values/active flags stay current.
  const [menuPath, setMenuPath] = useState<string[]>([]);

  const count = MOOD_SPECS.length;
  const sliceDeg = 360 / count;
  const size = 244;
  const cx = size / 2;
  const cy = size / 2;
  const rHub = 37;
  const rInnerRim = 89;
  const rOuterBezel = 118;

  // Sweep geometry for continuous rotary spectrum channels (-220° .. +40°, 260° arc)
  const ARC_START = -220;
  const ARC_SWEEP = 260;

  const activeMoodIdx = Math.max(
    0,
    MOOD_SPECS.findIndex((m) => m.id === moodId)
  );
  const activeSpec = MOOD_SPECS[activeMoodIdx];
  const activeRingIdx = INTENSITY_INDEX[intensityId] ?? 1;
  const clampedNorm = Math.max(0, Math.min(1, spectrumValueNorm));

  const cycleSpectrum = () => {
    if (!onChangeSpectrum) return;
    const idx = WHEEL_SPECTRUM_ORDER.findIndex((s) => s.id === spectrumId);
    const next = WHEEL_SPECTRUM_ORDER[(idx + 1) % WHEEL_SPECTRUM_ORDER.length];
    onChangeSpectrum(next.id);
  };

  const handleCenterTap = () => {
    if (spectrumId === 'mood') {
      const nextRing = INTENSITY_RINGS[(activeRingIdx + 1) % INTENSITY_RINGS.length].id;
      onSelect(moodId, nextRing);
      return;
    }
    onCycleMode?.();
  };

  const updateFromClientPos = (clientX: number, clientY: number) => {
    const svg = svgRef.current;
    if (!svg) return;
    const rect = svg.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;

    const x = ((clientX - rect.left) / rect.width) * size - cx;
    const y = ((clientY - rect.top) / rect.height) * size - cy;
    const dist = Math.hypot(x, y);
    if (dist < rHub * 0.9) return;

    if (spectrumId === 'mood') {
      const rawDeg = (Math.atan2(y, x) * 180) / Math.PI + 90 + sliceDeg / 2;
      const normDeg = ((rawDeg % 360) + 360) % 360;
      const idx = Math.floor(normDeg / sliceDeg) % count;
      const pickedMood = MOOD_SPECS[idx].id;

      const normR = Math.max(0, Math.min(1, (dist - rHub) / Math.max(1, rInnerRim - rHub)));
      let pickedIntensity: ProcessIntensityId = 'standard';
      if (normR < 0.34) pickedIntensity = 'subtle';
      else if (normR < 0.62) pickedIntensity = 'standard';
      else if (normR < 0.84) pickedIntensity = 'dramatic';
      else pickedIntensity = 'extreme';

      if (pickedMood !== moodId || pickedIntensity !== intensityId) {
        onSelect(pickedMood, pickedIntensity);
      }
      return;
    }

    if (onChangeSpectrumNorm) {
      // Map pointer angle onto the 260° bottom-gapped spectrum sweep (-220° .. +40°)
      const deg = (Math.atan2(y, x) * 180) / Math.PI;
      // Rotate into [0 .. 360) starting at bottom-left (+140° = -220°)
      const shifted = ((deg - ARC_START) % 360 + 360) % 360;
      const norm = shifted <= ARC_SWEEP ? shifted / ARC_SWEEP : shifted > 310 ? 0 : 1;
      onChangeSpectrumNorm(Math.max(0, Math.min(1, norm)));
    }
  };

  const handleWheelPointerDown = (e: React.PointerEvent<SVGSVGElement>) => {
    const svg = svgRef.current;
    if (!svg) return;
    const rect = svg.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * size - cx;
    const y = ((e.clientY - rect.top) / rect.height) * size - cy;
    const dist = Math.hypot(x, y);

    if (dist < rHub * 0.9) {
      handleCenterTap();
      return;
    }

    e.currentTarget.setPointerCapture(e.pointerId);
    setIsDragging(true);
    updateFromClientPos(e.clientX, e.clientY);
  };

  const handleWheelPointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!isDragging) return;
    updateFromClientPos(e.clientX, e.clientY);
  };

  const handleWheelPointerUp = (e: React.PointerEvent<SVGSVGElement>) => {
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
    setIsDragging(false);
  };

  const activeCenterDeg = -90 + activeMoodIdx * sliceDeg;
  const activeRadius =
    rHub + (rInnerRim - rHub) * (0.22 + (activeRingIdx / Math.max(1, INTENSITY_RINGS.length - 1)) * 0.72);
  const knobX = cx + activeRadius * Math.cos((activeCenterDeg * Math.PI) / 180);
  const knobY = cy + activeRadius * Math.sin((activeCenterDeg * Math.PI) / 180);

  const specDeg = ARC_START + clampedNorm * ARC_SWEEP;
  const specKnobR = (rHub + rInnerRim) * 0.5;
  const specKnobX = cx + specKnobR * Math.cos((specDeg * Math.PI) / 180);
  const specKnobY = cy + specKnobR * Math.sin((specDeg * Math.PI) / 180);

  const curSpectrumSpec = WHEEL_SPECTRUM_ORDER.find((s) => s.id === spectrumId) ?? WHEEL_SPECTRUM_ORDER[0];
  const singleLineReadout = spectrumDisplayText ?? `${activeSpec.label} · ${intensityId}`;

  return (
    <div className="flex flex-col items-center gap-2 py-2 px-2">
      {/* Single concise line of text for spectrum & vertical view status */}
      <div className="w-full flex items-center justify-between gap-2 text-[10px] leading-none border-b border-ridge/70 pb-1.5">
        <button
          type="button"
          onClick={cycleSpectrum}
          title="Cycle Wheel Spectrum"
          className="text-left font-bold tracking-wider uppercase text-ink hover:text-selection truncate transition-colors"
        >
          {singleLineReadout}
        </button>
        <button
          type="button"
          onClick={() => onCycleMode?.()}
          title="Switch Mode"
          className="shrink-0 font-bold uppercase tracking-wider text-mono-mid hover:text-accent-green whitespace-nowrap transition-colors"
        >
          {engineModeLabel} · {activeViewLabel}
        </button>
      </div>

      {/* Tactile Click-Wheel Hardware Dial */}
      <div className="relative w-[244px] h-[244px] flex items-center justify-center shrink-0">
        {/* Top Rim: Cycle Spectrum */}
        <button
          type="button"
          onClick={cycleSpectrum}
          aria-label="Cycle Spectrum"
          title="Cycle Active Spectrum"
          className="absolute top-0 left-1/2 -translate-x-1/2 z-20 min-w-[84px] min-h-[44px] flex items-start justify-center pt-1.5 text-[8.5px] font-bold tracking-[0.16em] uppercase text-mono-mid hover:text-selection active:scale-95 transition-all"
        >
          {curSpectrumSpec.label}
        </button>

        {/* Left Rim: Prev Body View */}
        <button
          type="button"
          onClick={() => onPrevView?.()}
          aria-label="Previous Body View"
          title="Previous Body View"
          className="absolute left-0 top-1/2 -translate-y-1/2 z-20 min-w-[44px] min-h-[48px] flex items-center justify-center text-[11px] font-bold text-mono-mid hover:text-selection active:scale-95 transition-all"
        >
          ◀◀
        </button>

        {/* Right Rim: Next Body View */}
        <button
          type="button"
          onClick={() => onNextView?.()}
          aria-label="Next Body View"
          title="Next Body View"
          className="absolute right-0 top-1/2 -translate-y-1/2 z-20 min-w-[44px] min-h-[48px] flex items-center justify-center text-[11px] font-bold text-mono-mid hover:text-selection active:scale-95 transition-all"
        >
          ▶▶
        </button>

        {/* Bottom Rim: Play / Pause */}
        <button
          type="button"
          onClick={() => onTogglePause?.()}
          aria-label={isPaused ? 'Resume animation' : 'Pause animation'}
          title={isPaused ? 'Resume Loop' : 'Pause Loop'}
          className={`absolute bottom-0 left-1/2 -translate-x-1/2 z-20 min-w-[76px] min-h-[44px] flex items-end justify-center pb-1.5 text-[9.5px] font-bold tracking-wider uppercase active:scale-95 transition-all ${
            isPaused ? 'text-accent-red' : 'text-mono-mid hover:text-accent-green'
          }`}
        >
          {isPaused ? '▶ PLAY' : '▶ ⏸'}
        </button>

        <svg
          ref={svgRef}
          viewBox={`0 0 ${size} ${size}`}
          className={`w-[244px] h-[244px] touch-none select-none ${
            isDragging ? 'cursor-grabbing' : 'cursor-pointer'
          }`}
          onPointerDown={handleWheelPointerDown}
          onPointerMove={handleWheelPointerMove}
          onPointerUp={handleWheelPointerUp}
          onPointerCancel={() => setIsDragging(false)}
        >
          <circle
            cx={cx}
            cy={cy}
            r={rOuterBezel}
            className="fill-mono-dark stroke-ridge"
            strokeWidth={1.5}
          />
          <circle
            cx={cx}
            cy={cy}
            r={rInnerRim}
            className="fill-mono-darker stroke-ridge"
            strokeWidth={1}
          />

          {spectrumId === 'mood' ? (
            <>
              {INTENSITY_RINGS.map((ring) => {
                const r = rHub + (rInnerRim - rHub) * ring.normR;
                const isCur = ring.id === intensityId;
                return (
                  <circle
                    key={ring.id}
                    cx={cx}
                    cy={cy}
                    r={r}
                    fill="none"
                    stroke="currentColor"
                    className={isCur ? 'text-selection/40' : 'text-ridge'}
                    strokeWidth={isCur ? 1.2 : 0.75}
                    strokeDasharray={ring.id === 'subtle' ? '2 2' : undefined}
                  />
                );
              })}

              {MOOD_SPECS.map((m, idx) => {
                const a0 = -90 + idx * sliceDeg - sliceDeg / 2 + 1.5;
                const a1 = -90 + idx * sliceDeg + sliceDeg / 2 - 1.5;
                const midA = ((-90 + idx * sliceDeg) * Math.PI) / 180;
                const isActive = m.id === moodId;
                const labelR = rHub + (rInnerRim - rHub) * 0.66;
                const lx = cx + labelR * Math.cos(midA);
                const ly = cy + labelR * Math.sin(midA);

                return (
                  <g key={m.id}>
                    <path
                      d={wedgePath(cx, cy, rHub + 3, rInnerRim, a0, a1)}
                      className={
                        isActive
                          ? 'fill-selection/20 stroke-selection'
                          : 'fill-mono-dark/70 stroke-ridge hover:fill-selection/10'
                      }
                      strokeWidth={isActive ? 1.5 : 0.85}
                    />
                    <text
                      x={lx}
                      y={ly + 2.5}
                      textAnchor="middle"
                      className={`text-[7px] font-bold uppercase tracking-tight pointer-events-none ${
                        isActive ? 'fill-selection' : 'fill-mono-mid'
                      }`}
                    >
                      {m.label}
                    </text>
                  </g>
                );
              })}

              <line
                x1={cx}
                y1={cy}
                x2={knobX}
                y2={knobY}
                className="stroke-accent-green pointer-events-none"
                strokeWidth={1.8}
                strokeLinecap="round"
              />
              <circle
                cx={knobX}
                cy={knobY}
                r={5}
                className="fill-accent-green stroke-paper pointer-events-none"
                strokeWidth={1.5}
              />
            </>
          ) : (
            <>
              {/* Continuous Spectrum Track */}
              <path
                d={arcPath(cx, cy, specKnobR, ARC_START, ARC_START + ARC_SWEEP)}
                fill="none"
                className="stroke-ridge"
                strokeWidth={12}
                strokeLinecap="round"
              />
              <path
                d={arcPath(cx, cy, specKnobR, ARC_START, specDeg)}
                fill="none"
                className="stroke-accent-green"
                strokeWidth={12}
                strokeLinecap="round"
              />
              {Array.from({ length: 11 }).map((_, idx) => {
                const a = ((ARC_START + (idx / 10) * ARC_SWEEP) * Math.PI) / 180;
                const r1 = specKnobR - 11;
                const r2 = specKnobR + 11;
                return (
                  <line
                    key={idx}
                    x1={cx + r1 * Math.cos(a)}
                    y1={cy + r1 * Math.sin(a)}
                    x2={cx + r2 * Math.cos(a)}
                    y2={cy + r2 * Math.sin(a)}
                    className="stroke-ridge/75 pointer-events-none"
                    strokeWidth={idx % 5 === 0 ? 1.5 : 0.8}
                  />
                );
              })}
              <circle
                cx={specKnobX}
                cy={specKnobY}
                r={8}
                className="fill-paper stroke-selection pointer-events-none"
                strokeWidth={2}
              />
            </>
          )}

          {/* Center Tactile Hub */}
          <circle
            cx={cx}
            cy={cy}
            r={rHub}
            className="fill-mono-dark stroke-accent-green/75"
            strokeWidth={1.6}
          />
          <text
            x={cx}
            y={cy - 3}
            textAnchor="middle"
            className="text-[8.5px] font-bold uppercase fill-ink pointer-events-none"
          >
            {spectrumId === 'mood' ? activeSpec.label : curSpectrumSpec.label}
          </text>
          <text
            x={cx}
            y={cy + 9}
            textAnchor="middle"
            className="text-[7px] font-bold uppercase fill-accent-green pointer-events-none"
          >
            {spectrumId === 'mood' ? intensityId : `${Math.round(clampedNorm * 100)}%`}
          </text>
        </svg>
      </div>

      {/* iPod-style drill-down menu */}
      {menuTree && menuTree.length > 0 && (() => {
        let level: ClickWheelMenuItem[] = menuTree;
        const crumbs: string[] = [];
        for (const id of menuPath) {
          const hit = level.find((m) => m.id === id);
          if (!hit?.children) break;
          crumbs.push(hit.label);
          level = hit.children;
        }
        const depth = crumbs.length;
        return (
          <div className="w-full max-w-[244px] border border-ridge/70 rounded-sm text-[10px] leading-tight">
            <div className="flex items-center justify-between gap-2 px-2 py-1 border-b border-ridge/70 text-mono-mid">
              <button
                type="button"
                disabled={depth === 0}
                onClick={() => setMenuPath((p) => p.slice(0, depth - 1))}
                className="font-bold uppercase tracking-wider hover:text-selection disabled:opacity-30 disabled:hover:text-mono-mid"
                aria-label="Back"
              >
                ◀ Menu
              </button>
              <span className="truncate font-bold uppercase tracking-wider text-ink">
                {depth === 0 ? statusHeadline ?? 'Menu' : crumbs[depth - 1]}
              </span>
            </div>
            <ul className="max-h-[168px] overflow-y-auto">
              {level.map((item) => {
                const isBranch = !!item.children?.length;
                return (
                  <li key={item.id}>
                    <button
                      type="button"
                      onClick={() => {
                        if (isBranch) setMenuPath((p) => [...p.slice(0, depth), item.id]);
                        else item.onSelect?.();
                      }}
                      className={`w-full flex items-center justify-between gap-2 px-2 py-1.5 text-left hover:bg-selection/10 transition-colors ${
                        item.isActive ? 'text-accent-green font-bold' : 'text-ink'
                      }`}
                    >
                      <span className="truncate">{item.label}</span>
                      <span className="shrink-0 text-mono-mid">
                        {item.valueText ? `${item.valueText} ` : ''}
                        {isBranch ? '▶' : item.isActive ? '●' : ''}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        );
      })()}
    </div>
  );
};
